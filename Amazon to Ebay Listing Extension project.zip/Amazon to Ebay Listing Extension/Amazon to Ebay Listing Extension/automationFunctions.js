function setTextArea(input, text) {
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set
    nativeInputValueSetter.call(input, text)

    const event = new Event('input', { bubbles: true })
    input.dispatchEvent(event)
}

function scrollToElement(element) {
    element?.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });
}

function pasteText(div, text) {
    const dt = new DataTransfer()
    dt.setData('text/plain', text)

    const pasteEvent = new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })
    div.dispatchEvent(pasteEvent)
}

const simulateMouseFocus = (element) => {
    ['mousedown', 'click', 'focus'].forEach(mouseEventType =>
        element.dispatchEvent(
            new MouseEvent(mouseEventType, {
                view: window,
                bubbles: true,
                cancelable: true,
                buttons: 1
            })
        )
    );
};

function checkElement(selector) {
    return new Promise((resolve) => {
        const intervalId = setInterval(() => {
            if (document.querySelector(selector)) {
                clearInterval(intervalId);
                resolve(true);
            }
        }, 100);
    });
}
function waitForElement(selector, timeout = 5000) {
    return new Promise((resolve, reject) => {
        const start = Date.now();
        const interval = setInterval(() => {
            const element = document.querySelector(selector);
            if (element) {
                clearInterval(interval);
                resolve(element);
            } else if (Date.now() - start > timeout) {
                clearInterval(interval);
                reject(`Element ${selector} not found within ${timeout}ms`);
            }
        }, 100);
    });
}

function checkElementPosted(selector) {
    return new Promise((resolve) => {
        const intervalId = setInterval(() => {
            if (document.querySelector(selector).innerText.includes('Posted')) {
                clearInterval(intervalId);
                resolve(true);
            }
        }, 100);
    });
}



function getRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}


async function uploadImageFromLink(imagePath) {
    try {

        // const imagePath = chrome.runtime.getURL(`images/${imageName}`)
        console.log(imagePath);
        const res = await fetch(imagePath)


        const blob = await res.blob()
        console.log(blob)
        const file = new File([blob], 'image.jpeg', { type: blob.type });

        const inputElement = document.querySelector('input[type="file"]')
        if (!inputElement) {
            throw new Error('Input element not found');
        }

        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);

        // Assign the files to the input element
        inputElement.files = dataTransfer.files;
        const changeEvent = new Event('change', { bubbles: true });
        console.log(inputElement)
        inputElement.dispatchEvent(changeEvent);
        return true
    } catch (error) {
        console.log('Error uploading image:', error);
        return false;
    }
}

function setTextArea(input, text){
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLDivElement.prototype, 'value').set
    nativeInputValueSetter.call(input,text)

    const event = new Event('input', {bubbles: true})
    input.dispatchEvent(event)
}