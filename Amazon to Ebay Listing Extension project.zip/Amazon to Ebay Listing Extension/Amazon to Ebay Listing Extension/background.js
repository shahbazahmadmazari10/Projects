chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "openAmazonAndInject") {
    // Retrieve both values from storage
    chrome.storage.local.get(["index", "productUrls"], (result) => {
      const index = result.index ?? 0;
      const productURLs = result.productUrls ?? [];

      if (!productURLs.length || index >= productURLs.length) {
        console.error("❌ Invalid product URL list or index out of bounds.");
        return;
      }

      const url = productURLs[index];

      // Open new tab
      chrome.tabs.create({ url }, (tab) => {
        const tabId = tab.id;

        // Wait for the tab to fully load
        chrome.tabs.onUpdated.addListener(function listener(updatedTabId, info) {
          if (updatedTabId === tabId && info.status === "complete") {
            chrome.scripting.executeScript({
              target: { tabId },
              files: ["content.js"]
            }).then(() => {
              console.log("✅ content.js injected from background");
            }).catch((err) => {
              console.error("❌ Failed to inject content.js from background:", err);
            });

            // Remove the listener after use
            chrome.tabs.onUpdated.removeListener(listener);
          }
        });
      });
    });
  }

  // Open eBay
  if (message.action === "openEbay") {
    chrome.tabs.create({ url: "https://www.ebay.com/sl/prelist/suggest" });
  }

  // Close current tab
  if (message.action === "closeCurrentTab" && sender.tab?.id) {
    chrome.tabs.remove(sender.tab.id);
  }

});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.action === "generateEbayContent") {
    const { title, description } = message;
    const apiKey = "AIzaSyD6NSZ1CNivEyEuLyoiPMSmFkd7JWrDd5w";

    const prompt = `
    You are an eBay listing optimization expert.
    Given the following product info:
    Title: "${title}"
    Description: "${description}"
    Rewrite both the title and description to be concise and SEO optimized for an eBay listing.
    - The title should be max 80 characters.
    - The description should be 2-3 short, keyword-rich sentences.
    - Keep formatting simple.
    - Respond in JSON format only, no markdown, no extra text:
    {
      "title": "Your optimized title here",
      "description": "Your optimized description here"
    }
    `;

    fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { responseMimeType: "application/json" }
        })
      }
    )
      .then(async (res) => {
        if (!res.ok) {
          const errBody = await res.text();
          throw new Error(`API request failed [${res.status}]: ${errBody}`);
        }
        return res.json();
      })
      .then((data) => {
        console.log("📦 Gemini Raw Response:", JSON.stringify(data, null, 2));
        const rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text;
        if (!rawText) {
          const reason = data?.candidates?.[0]?.finishReason;
          throw new Error(`No response text. finishReason: ${reason ?? "unknown"}`);
        }
        const parsed = JSON.parse(rawText.replace(/```json|```/g, "").trim());
        sendResponse({
          title: parsed.title || "⚠️ Title missing",
          description: parsed.description || "⚠️ Description missing"
        });
      })
      .catch((err) => {
        console.error("❌ Gemini error in background:", err.message);
        sendResponse({
          title: "❌ Error generating title.",
          description: "❌ Error generating description.",
          debug: err.message
        });
      });

    return true; // ← keeps the message channel open for async response
  }

  // your existing handlers below...
  if (message.action === "openEbay") { /* ... */ }
  if (message.action === "closeCurrentTab") { /* ... */ }
});