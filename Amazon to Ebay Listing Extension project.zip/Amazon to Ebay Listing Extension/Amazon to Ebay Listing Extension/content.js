(async () => {

  const title = document.querySelector('#productTitle')?.innerText.trim() || "No title found";
  const price = document.querySelector('span[class="a-offscreen"]')?.innerText.trim() || "No price found";

  const descriptionArray = document.querySelectorAll('#feature-bullets ul li span.a-list-item');

  const description = Array.from(descriptionArray)
    .map(el => el.innerText.trim())
    .filter(text => text.length > 0)
    .join(". ") + ".";

  console.log(description);

  const productUrl = window.location.href;

  function extractASIN(url) {
    const match = url.match(/\/dp\/([A-Z0-9]{10})/);
    return match ? match[1] : null;
  }

  const asin = extractASIN(productUrl);

  console.log("ASIN:", asin);

  const modelNumber = Array.from(document.querySelectorAll('tr'))
    .find(row => row.querySelector('th')?.textContent.trim() === 'Item model number')
    ?.querySelector('td');

  const model = modelNumber?.innerText.trim();

  const ProductType = Array.from(document.querySelectorAll('tr'))
    .find(row => row.querySelector('th')?.textContent.trim() === 'Earpiece Shape')
    ?.querySelector('td');

  const type = ProductType?.innerText.trim();

  const ProductConnectivity = Array.from(document.querySelectorAll('tr'))
    .find(row => row.querySelector('th')?.textContent.trim() === 'Wireless Communication Technology')
    ?.querySelector('td');

  const connectivity = ProductConnectivity?.innerText.trim();

  // ── Calculate eBay price with profit ──
  const { profitMode, profitValue } = await chrome.storage.local.get(["profitMode", "profitValue"]);
  const numericPrice = parseFloat(price.replace(/[^0-9.]/g, '')) || 0;
  const profitAmt = parseFloat(profitValue) || 5; // default 5% if not set
  let ebayPrice;

  if (profitMode === "fixed") {
    // Add a flat dollar amount
    ebayPrice = numericPrice + profitAmt;
  } else {
    // Default: percentage markup
    ebayPrice = numericPrice + (numericPrice * profitAmt / 100);
  }

  ebayPrice = parseFloat(ebayPrice.toFixed(2));
  console.log(`💰 Amazon: $${numericPrice} | Mode: ${profitMode || "percentage"} | Profit: ${profitAmt} | eBay: $${ebayPrice}`);

  const headerImagePath = chrome.runtime.getURL("header_optimized.png");
  const imagesUrls = [headerImagePath];

  const list = document.querySelectorAll('ul[role="radiogroup"]')[0]
  const imageElements = list.querySelectorAll('img')
  for (let i = 1; i < imageElements.length - 1; i++) {
    const url = imageElements[i]?.getAttribute('src');
    if (url) imagesUrls.push(url);
  }

  const cleanedImagesUrls = imagesUrls.map(url => url.replace(/\._[^.]+_/, ''));

  const concisedTitleAndDescription = await generateEbayOptimizedContent(title, description)

  const concisedTitle = concisedTitleAndDescription.title
  const concisedDescription = concisedTitleAndDescription.description

  const productData = {
    title,
    description,
    price: ebayPrice,
    amazonPrice: numericPrice,
    rawAmazonPrice: price,
    asin,
    model,
    type,
    connectivity,
    concisedTitle,
    concisedDescription,
    ImagesUrls: cleanedImagesUrls,
  };

  storeDataAndRedirect(productData);
})()

//helper Functions
async function storeDataAndRedirect(productData) {
  await chrome.storage.local.set({ productData });

  const result = await chrome.storage.local.get("productData");
  console.log("✅ Data Taken from Storage:", result.productData);

  chrome.runtime.sendMessage({ action: "openEbay" });
  chrome.runtime.sendMessage({ action: "closeCurrentTab" });
}

async function generateEbayOptimizedContent(title, description) {
  const apiKey = "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";

  const prompt = `
  You are an eBay listing optimization expert.

  Given the following product info:

  Title: "${title}"

  Description: "${description}"

  Rewrite both the title and description to be concise and SEO optimized for an eBay listing. 
  - The title should be max 80 characters.
  - The description should be 2-3 short, keyword-rich sentences.
  - Keep formatting simple.
  - Respond in JSON format only, like this:
  {
    "title": "Your optimized title here",
    "description": "Your optimized description here"
  }
  `;

  try {
    const res = await fetch(
      "https://api.groq.com/openai/v1/chat/completions",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: "openai/gpt-oss-120b",
          messages: [
            {
              role: "user",
              content: prompt
            }
          ]
        })
      }
    );

    const data = await res.json();
    console.log("📦 Groq API Raw Response:", JSON.stringify(data, null, 2));

    let rawText = data?.choices?.[0]?.message?.content;

    if (!rawText) {
      throw new Error("❌ No response text from Groq.");
    }

    // Clean and extract JSON safely
    rawText = rawText
      .replace(/```json|```/g, "")
      .replace(/^[^{]*({[\s\S]*})[^}]*$/m, "$1")
      .trim();

    console.log("🧪 Cleaned Groq Response:", rawText);

    const parsed = JSON.parse(rawText);

    return {
      title: parsed.title || "⚠️ Title missing",
      description: parsed.description || "⚠️ Description missing"
    };

  } catch (err) {
    console.error("❌ Groq API error:", err.message || err);
    return {
      title: "❌ Error generating title.",
      description: "❌ Error generating description.",
      debug: err.message || "Unknown error"
    };
  }
}