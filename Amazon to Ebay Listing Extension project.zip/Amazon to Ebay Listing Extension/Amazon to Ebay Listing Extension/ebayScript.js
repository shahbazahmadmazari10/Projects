// ✅ ebayScript injected

(async () => {
  try {
    const result = await chrome.storage.local.get("productData");
    const productData = result.productData;
    console.log("📦 Product Data:", productData);

    const currentUrl = window.location.href;

    if (currentUrl.includes("/prelist/")) {
      console.log("📝 Prelist page detected");
      const inputEl = document.querySelector('input[type="text"]');
      if (inputEl && productData?.concisedTitle) {
        inputEl.value = productData.concisedTitle;
        inputEl.dispatchEvent(new Event("input", { bubbles: true }));
        inputEl.dispatchEvent(new Event("change", { bubbles: true }));
        console.log("✅ Title inserted and event dispatched");
      }

      await delay(3000);
      const runOutBtn = document.querySelector('button[aria-label*="run out"]');
      if (runOutBtn) {
        simulateUserClick(runOutBtn);
        console.log("✅ Clicked 'run out' button");
      }

      console.log("🔍 Waiting for next button...");
      await checkElement('div.prelist-radix__next-container button');
      const nextBtn = document.querySelector('div.prelist-radix__next-container button');
      if (nextBtn) {
        simulateUserClick(nextBtn);
        console.log("✅ Clicked 'Next'");
      }

      await delay(2000);
      // const radioInput = document.querySelector('div[class="field se-radio-group__option"] input[type="radio"]')
      // radioInput.focus()
      // if (radioInput) {
      //   radioInput.click();
      //   console.log("✅ Radio selected");
      // }
      // const radioInputs = document.querySelectorAll('div.se-radio-group__option input[type="radio"]');
      const labels = document.querySelectorAll('div.se-radio-group__option label');

      for (let i = 0; i < labels.length; i++) {
        if (labels[i].innerText.trim().toLowerCase() === "new") {
          simulateUserClick(labels[i]); // Clicking the label, not the input
          console.log("✅ Clicked 'New' condition label");
          break;
        }
      }


      await delay(2000);
      const buttons = document.querySelectorAll('div.lightbox-dialog__main button');
      const continueBtn = Array.from(buttons).find(btn => btn.innerText.toLowerCase().includes("continue"));
      if (continueBtn) {
        simulateUserClick(continueBtn);
        console.log("✅ Clicked Continue");
      }

    } else if (currentUrl.includes("/lstng")) {
      console.log("📄 Listing page detected — uploading images & setting format");
      
      const collageBlob = await generateCollageImage([...productData.ImagesUrls]); // Use clone
      const collageUrl = URL.createObjectURL(collageBlob);
      productData.ImagesUrls.shift(); // Remove header
      productData.ImagesUrls.unshift(collageUrl); // Add collage

      const imagesLink = productData?.ImagesUrls;
      if (Array.isArray(imagesLink) && imagesLink.length > 0) {
        await checkElement('input[type="file"]');
        for (let i = 0; i < imagesLink.length; i++) {
          const url = imagesLink[i];
          console.log(`📤 Uploading image ${i + 1}:`, url);
          const success = await uploadImageFromLink(url);
          if (!success) {
            console.warn(`⚠️ Failed to upload image ${i + 1}`);
          }
        }
      } else {
        console.warn("⚠️ No valid ImagesUrls array found");
      }

      const inputE2 = document.querySelector('input[name="title"]');
      scrollToElement(inputE2);
      if (inputE2 && productData?.concisedTitle) {
        inputE2.value = productData.concisedTitle;
        inputE2.dispatchEvent(new Event("input", { bubbles: true }));
        inputE2.dispatchEvent(new Event("change", { bubbles: true }));
        console.log("✅ Title inserted and event dispatched");
      }

      try {
        const iframe = await checkElement('iframe[title*="Description"]');
        const iframeDoc = iframe?.contentDocument || iframe?.contentWindow?.document;
        const desElement = iframeDoc?.querySelector('body div[aria-label="Description"]')

        if (desElement && productData?.concisedDescription) {
          scrollToElement(desElement);
          desElement.focus();
          desElement.innerText = productData.concisedDescription;
          desElement.dispatchEvent(new Event("input", { bubbles: true }));
          desElement.dispatchEvent(new Event("change", { bubbles: true }));
          console.log("✅ Description inserted into rich text editor");
        } else {
          console.warn("⚠️ Description editor not found or missing content");
        }
      } catch (err) {
        console.error("❌ Error finding Description field:", err);
      }

      await delay(3000);
      const priceHeader = document.querySelector('div.smry.summary__price h2');
      scrollToElement(priceHeader);
      const formatBtn = document.querySelector('div.summary__price-fields button[aria-haspopup="listbox"]');
      if (formatBtn) {
        simulateUserClick(formatBtn);
        console.log("✅ Format button clicked");
      } else {
        console.warn("⚠️ Format button not found");
      }
      document.querySelectorAll('span[class*="listbox-button"] [role="option"]')[1].click();

      const priceField = await checkElement('input[aria-label="Item price"]');
      if (priceField && productData?.price) {
        priceField.value = productData.price.toString();
        priceField.dispatchEvent(new Event('input', { bubbles: true }));
        priceField.dispatchEvent(new Event('change', { bubbles: true }));
        console.log("✅ Price inserted:", productData.price);
      } else {
        console.warn("⚠️ Price input field not found or product price missing");
      }

      // // --- Model ---
      // await fillAttribute({
      //   buttonIndex: 3,
      //   inputSelector: 'input[name="search-box-attributesModel"]',
      //   value: productData?.model,
      //   addButtonSelector: 'div[class="se-field--fluid"] > button'
      // });

      // // --- Type ---
      // await fillAttribute({
      //   buttonIndex: 6,
      //   inputSelector: 'input[name="search-box-attributesType"]',
      //   value: productData?.type,
      //   addButtonSelector: 'div[class*="customOptions"] button',
      //   addButtonTimeout: 7000 
      // });

      // // --- Connectivity ---
      // await fillAttribute({
      //   buttonIndex: 10,
      //   inputSelector: 'input[name="search-box-attributesConnectivity"]',
      //   value: productData?.connectivity,
      //   optionSelectors: [
      //     'span[name="customOptions-attributesConnectivity"] span.filter-menu__text',
      //     'span[name="searchedOptions-attributesConnectivity"] span.filter-menu__text'
      //   ],
      //   closeButtonIndex: 10
      // });

      await putModel(productData?.model);
      await putType(productData?.type);
      await putConnectivity(productData?.connectivity);




    } else {
      console.warn("⚠️ Unknown page. Script skipped.");
    }

  } catch (err) {
    console.error("❌ Script error:", err);
  }
  const { index } = await chrome.storage.local.get("index");
  const newIndex = (index ?? 0) + 1;
  await chrome.storage.local.set({ index: newIndex });
  chrome.runtime.sendMessage({ action: "openAmazonAndInject" });

})();

async function fillAttribute({ buttonIndex, inputSelector, value, addButtonSelector = null,addButtonTimeout, optionSelectors = [], closeButtonIndex = null }) {
  try {
    // Open dropdown
    const buttons = document.querySelectorAll('div.se-field--fluid button');
    if (buttons[buttonIndex]) simulateUserClick(buttons[buttonIndex]);
    else throw new Error(`Button at index ${buttonIndex} not found`);

    // Wait for input to load
    const input = await checkElement(inputSelector);
    input.value = value ?? '';
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    console.log(`✅ Value '${value}' inserted into ${inputSelector}`);

    await delay(3000);

    if (addButtonSelector) {
      const addBtn = await checkElement(addButtonSelector, addButtonTimeout ?? 3000);
      simulateUserClick(addBtn);
      console.log("✅ Clicked add button");
    } else if (optionSelectors.length > 0) {
      let clicked = false;
      for (const selector of optionSelectors) {
        const options = document.querySelectorAll(selector);
        for (const opt of options) {
          const text = opt.innerText.trim().toLowerCase();
          if (text.includes(value?.toLowerCase())) {
            simulateUserClick(opt);
            clicked = true;
            console.log(`✅ Option clicked: ${selector} with text '${text}'`);
            break;
          }
        }
        if (clicked) break;
      }

      if (!clicked) console.warn("⚠️ No matching option found");

      if (closeButtonIndex !== null && buttons[closeButtonIndex]) {
        simulateUserClick(buttons[closeButtonIndex]);
        console.log("✅ Closed dropdown after selection");
      }
    }
  } catch (err) {
    console.error("❌ Error filling attribute:", err);
  }
}


function simulateUserClick(el) {
  const evt = new MouseEvent("click", {
    bubbles: true,
    cancelable: true,
    view: window,
  });
  el.dispatchEvent(evt);
}

function checkElement(selector, timeout = 10000) {
  return new Promise((resolve, reject) => {
    const interval = 200;
    let elapsed = 0;

    const check = () => {
      const element = document.querySelector(selector);
      if (element) {
        resolve(element);
      } else if (elapsed >= timeout) {
        reject(new Error(`Element ${selector} not found within ${timeout}ms`));
      } else {
        elapsed += interval;
        setTimeout(check, interval);
      }
    };
    check();
  });
}

function delay(ms) {
  return new Promise(res => setTimeout(res, ms));
}

function scrollToElement(el) {
  if (el) {
    el.scrollIntoView({ behavior: "smooth", block: "center" });
  }
}

async function generateCollageImage(imageUrls) {
const canvas = document.createElement("canvas");

// Original image sizes
const headerOriginalWidth = 1280;
const headerOriginalHeight = 290;
const mainOriginalWidth = 1600;
const mainOriginalHeight = 1600;

// Scale factor for consistency
const scaleFactor = 0.5;

// Scaled image sizes
const headerHeight = headerOriginalHeight * scaleFactor; // 145
const mainImageWidth = mainOriginalWidth * scaleFactor; // 800
const mainImageHeight = mainOriginalHeight * scaleFactor; // 800

// Left column
const leftImageCount = 3;
const leftColWidth = 200;
const leftImageHeight = mainImageHeight / leftImageCount; // 266.67

// Final canvas size
const canvasWidth = leftColWidth + mainImageWidth; // 200 + 800 = 1000
const canvasHeight = headerHeight + mainImageHeight; // 145 + 800 = 945

canvas.width = canvasWidth;
canvas.height = canvasHeight;


  const ctx = canvas.getContext("2d");

  const imgs = await Promise.all(imageUrls.slice(0, 5).map(loadImage));

  ctx.drawImage(imgs[0], 0, 0, canvasWidth, headerHeight);
  ctx.drawImage(imgs[1], 0, headerHeight, leftColWidth, leftImageHeight);
  ctx.drawImage(imgs[2], 0, headerHeight + leftImageHeight, leftColWidth, leftImageHeight);
  ctx.drawImage(imgs[3], 0, headerHeight + 2 * leftImageHeight, leftColWidth, leftImageHeight);
  ctx.drawImage(imgs[4], leftColWidth, headerHeight, mainImageWidth, mainImageHeight);

  // Set border style
  ctx.strokeStyle = "#000"; // black
  ctx.lineWidth = 2;

  // Draw border around the full canvas
  ctx.strokeRect(0, 0, canvas.width, canvas.height);

  //   // Border around header
  // ctx.strokeStyle = "#333";
  // ctx.strokeRect(0, 0, canvas.width, headerHeight);

  // // Border around left column
  // ctx.strokeStyle = "#666";
  // ctx.strokeRect(0, headerHeight, leftColWidth, mainImageHeight);

  // // Border around main image area
  // ctx.strokeStyle = "#999";
  // ctx.strokeRect(leftColWidth, headerHeight, mainImageWidth, mainImageHeight);



  return new Promise(resolve => {
    canvas.toBlob(blob => {
      resolve(blob);
    }, "image/jpeg", 0.95);
  });
}

function loadImage(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });
}

async function putModel(model){
        //Model
      document.querySelectorAll('div[class="se-field--fluid"] button')[3].click();

      const input = document.querySelector('input[name="search-box-attributesModel"]');
      input.value = model;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));

      setTimeout(()=>{
      const addBtn = document.querySelector('div[class="se-field--fluid"] > button');
      addBtn.click()
      }, 1000)
}

async function putType (type){
  //Type
      setTimeout(()=>{
      document.querySelectorAll('div[class="se-field--fluid"] button')[6].click()
      const inputEle = document.querySelector('input[name="search-box-attributesType"]')
      inputEle.value = type
      inputEle.dispatchEvent(new Event('input', {bubbles: true}))
      inputEle.dispatchEvent(new Event('change', {bubbles: true}))
      }, 3000)
      setTimeout(()=>{
      const addBtn = document.querySelector('div[class*="customOptions"] button');
      addBtn.click()
      }, 3000)
}

async function putConnectivity(connectivity){
  try {
    // Open the dropdown
    const dropdownBtn = document.querySelectorAll('div[class="se-field--fluid"] button')[10];
    dropdownBtn.focus();
    if (dropdownBtn) dropdownBtn.click();

    // Wait for input box
    const inputElem = await waitForElement('input[name="search-box-attributesConnectivity"]', 5000);
    inputElem.value = connectivity;
    inputElem.dispatchEvent(new Event('input', { bubbles: true }));
    inputElem.dispatchEvent(new Event('change', { bubbles: true }));

    // Try custom option first
    let optionClicked = false;
    try {
      const customOption = await waitForElement('span[name="customOptions-attributesConnectivity"] span.filter-menu__text', 4000);
      customOption.click();
      optionClicked = true;
    } catch (err) {
      console.log("Custom option not found. Trying searchedOptions...");
    }

    // Fallback: searched options
    if (!optionClicked) {
      try {
        const searchedOption = await waitForElement('span[name="searchedOptions-attributesConnectivity"] span.filter-menu__text', 4000);
        searchedOption.click();
        optionClicked = true;
      } catch (err) {
        console.warn("Searched option not found. Skipping click.");
      }
    }

    // Close dropdown if it was opened
    if (optionClicked && dropdownBtn) {
      dropdownBtn.click();
    }

  } catch (err) {
    console.error("putConnectivity() failed:", err);
  }
}