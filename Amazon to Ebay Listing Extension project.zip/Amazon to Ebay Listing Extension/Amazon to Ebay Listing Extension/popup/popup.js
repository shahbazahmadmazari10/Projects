const btn = document.getElementById('btnStart');
const input = document.getElementById('txtInput');
let file = false;
let data = [];

// ── Profit mode toggle ──
let profitMode = "percentage"; // "percentage" | "fixed"
const btnPercentage = document.getElementById("btnPercentage");
const btnFixed = document.getElementById("btnFixed");
const profitPrefix = document.getElementById("profitPrefix");
const profitValueInput = document.getElementById("profitValue");
const profitHint = document.getElementById("profitHint");

function setActiveMode(mode) {
  profitMode = mode;
  if (mode === "percentage") {
    btnPercentage.classList.add("active");
    btnFixed.classList.remove("active");
    profitPrefix.textContent = "%";
    profitHint.textContent = `Adds ${profitValueInput.value || 0}% on top of Amazon price`;
  } else {
    btnFixed.classList.add("active");
    btnPercentage.classList.remove("active");
    profitPrefix.textContent = "$";
    profitHint.textContent = `Adds $${profitValueInput.value || 0} flat on top of Amazon price`;
  }
}

btnPercentage.addEventListener("click", () => setActiveMode("percentage"));
btnFixed.addEventListener("click", () => setActiveMode("fixed"));

profitValueInput.addEventListener("input", () => {
  const v = profitValueInput.value || 0;
  if (profitMode === "percentage") {
    profitHint.textContent = `Adds ${v}% on top of Amazon price`;
  } else {
    profitHint.textContent = `Adds $${v} flat on top of Amazon price`;
  }
});

// Load saved profit settings on popup open
chrome.storage.local.get(["profitMode", "profitValue"], (result) => {
  if (result.profitMode) {
    setActiveMode(result.profitMode);
  }
  if (result.profitValue !== undefined && result.profitValue !== null) {
    profitValueInput.value = result.profitValue;
    // Trigger hint update
    profitValueInput.dispatchEvent(new Event("input"));
  }
});

btn.addEventListener("click", async () => {
  const amazonProductUrlPattern = /^https:\/\/www\.amazon\.com\/.*\/dp\/[A-Z0-9]{10}/;
  let productsUrls = []; // ✅ Declare it once, outside

  if (!file) {
    const inputValue = input.value.trim();
    productsUrls = inputValue
      .split(",")
      .map(url => url.trim())
      .filter(url => url.length > 0);
  } else {
    productsUrls = data
      .map(row => row["Product Url"])
      .filter(url => typeof url === "string" && url.length > 0);
  }

  // ✅ Validate all URLs
  for (const url of productsUrls) {
    if (!amazonProductUrlPattern.test(url) && !url.includes("amazon.com/gp/product/")) {
      alert(`❌ Invalid Amazon URL: ${url}`);
      return;
    }
  }

  // ✅ Validate profit value
  const profitVal = parseFloat(profitValueInput.value);
  if (isNaN(profitVal) || profitVal < 0) {
    alert("❌ Please enter a valid profit value (0 or above).");
    return;
  }

  // ✅ Save product URLs, index, and profit settings
  await chrome.storage.local.set({
    productUrls: productsUrls,
    index: 0,
    profitMode: profitMode,
    profitValue: profitVal
  });

  chrome.runtime.sendMessage({ action: "openAmazonAndInject" });
  window.close();
});

document.getElementById("excelInput").addEventListener("change", async () => {
  try {
    data = await getDataFromUserFile();
    console.log("✅ Excel data:", data);
    file = true;
  } catch (err) {
    alert(err);
  }
});

async function getDataFromUserFile() {
  return new Promise((resolve, reject) => {
    const input = document.getElementById("excelInput");
    const file = input.files[0];

    if (!file || !file.name.endsWith(".xlsx")) {
      reject("❌ Please select a valid .xlsx file.");
      return;
    }

    const reader = new FileReader();

    reader.onload = (event) => {
      try {
        const arrayBuffer = event.target.result;
        const workbook = XLSX.read(arrayBuffer, { type: "array" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const range = { s: { r: 0, c: 0 }, e: { r: 1300, c: 4 } };

        let jsonData = XLSX.utils.sheet_to_json(sheet, { header: 2, range });
        resolve(jsonData.flat(Infinity));
      } catch (error) {
        reject("❌ Failed to parse Excel file: " + error.message);
      }
    };

    reader.onerror = () => reject("❌ Failed to read the file.");
    reader.readAsArrayBuffer(file);
  });
}
