//Model
document.querySelectorAll('div[class="se-field--fluid"] button')[3].click();

const input = document.querySelector('input[name="search-box-attributesModel"]');
input.value = '3510';
input.dispatchEvent(new Event("input", { bubbles: true }));
input.dispatchEvent(new Event("change", { bubbles: true }));

setTimeout(()=>{
const addBtn = document.querySelector('div[class="se-field--fluid"] > button');
addBtn.click()
}, 1000)



//Connectivity
document.querySelectorAll('div[class="se-field--fluid"] button')[10].click()
const inputEle = document.querySelector('input[name="search-box-attributesConnectivity"]')
inputEle.value = "bluetooth"
inputEle.dispatchEvent(new Event('input', {bubbles: true}))
inputEle.dispatchEvent(new Event('change', {bubbles: true}))


setTimeout(()=>{
const addBtn = document.querySelector('span[name="customOptions-attributesConnectivity"] span[class="filter-menu__text"]')
  if(addBtn){
    addBtn.click()
  }
  else{
  document.querySelector('span[name="searchedOptions-attributesConnectivity"] span[class="filter-menu__text"]').click()
  }
  document.querySelectorAll('div[class="se-field--fluid"] button')[10].click()
}, 1000)

//Type


document.querySelectorAll('div[class="se-field--fluid"] button')[6].click()
const inputEle = document.querySelector('input[name="search-box-attributesType"]')
inputEle.value = "ups"
inputEle.dispatchEvent(new Event('input', {bubbles: true}))
inputEle.dispatchEvent(new Event('change', {bubbles: true}))

setTimeout(()=>{
const addBtn = document.querySelector('div[class*="customOptions"] button');
addBtn.click()
}, 1000)



