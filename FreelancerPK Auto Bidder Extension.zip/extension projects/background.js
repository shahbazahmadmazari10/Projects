/**
 * background.js — Service Worker Orchestrator
 * Controls the automation loop: navigate, scrape, generate proposal via backend, fill, submit.
 * All AI requests go through the secure backend proxy — no API key in extension.
 */

// Import ApiClient for Apps Script communication
importScripts('utils/api.js');
let isRunning = false;
let settings = {};
let bidCount = 0;
let currentPage = 1;

// ===== Message Handler =====
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'startAutomation') {
    settings = message.settings;
    // Fire-and-forget — respond immediately, automation runs in background
    sendResponse({ success: true });
    startAutomation();
    return false;
  }
  if (message.action === 'stopAutomation') {
    stopAutomation('User stopped automation');
    sendResponse({ success: true });
    return false;
  }
  if (message.action === 'getStatus') {
    sendResponse({ isRunning, bidCount, currentPage });
    return false;
  }
});

// ===== Core Automation Loop =====
async function startAutomation() {
  if (isRunning) return;
  isRunning = true;
  bidCount = 0;
  currentPage = 1;

  log('🚀 Automation started', 'success');
  broadcastStatus('running');

  try {
    await runLoop();
  } catch (err) {
    log(`❌ Fatal error: ${err.message}`, 'error');
  } finally {
    stopAutomation('Automation completed');
  }
}

function stopAutomation(reason) {
  if (!isRunning && reason !== 'User stopped automation') return;
  isRunning = false;
  log(`⏹ Stopped: ${reason}`, 'warning');
  broadcastStatus('idle');
  broadcastStats();
}

async function runLoop() {
  const maxBids = settings.maxBids || 15;

  while (isRunning && bidCount < maxBids) {
    log(`📄 Loading jobs page ${currentPage}...`, 'info');

    const jobsUrl = currentPage === 1
      ? 'https://www.freelancer.pk/jobs/'
      : `https://www.freelancer.pk/jobs/${currentPage}`;

    const tab = await navigateToUrl(jobsUrl);
    if (!tab) { log('❌ Failed to open jobs page', 'error'); break; }

    // Wait for page load completion instead of static delay
    await waitForTabLoad(tab.id);
    await injectContentScripts(tab.id);
    // Small delay for content scripts to initialize
    await smartDelay(500);

    const scrapeResult = await sendTabMessage(tab.id, { action: 'scrapeProjects' });
    if (!scrapeResult?.success || !scrapeResult.projects?.length) {
      log(`⚠ No projects found on page ${currentPage}`, 'warning');
      currentPage++;
      if (currentPage > 10) { log('Reached page limit (10).', 'warning'); break; }
      continue;
    }

    log(`📋 Found ${scrapeResult.projects.length} projects`, 'info');

    const keywords = parseKeywords(settings.keywords);
    const matchingProjects = filterByKeywords(scrapeResult.projects, keywords);
    log(`🔍 ${matchingProjects.length} match keywords`, 'info');
    updateStat('projectsScanned', scrapeResult.projects.length);

    for (const project of matchingProjects) {
      if (!isRunning || bidCount >= maxBids) break;

      const processed = await getProcessedProjects();
      if (processed[project.projectId]) {
        log(`⏭ Skipping (already bid): ${project.title.substring(0, 40)}...`, 'info');
        continue;
      }

      log(`🔗 Opening: ${project.title.substring(0, 50)}...`, 'info');
      await navigateTabToUrl(tab.id, project.projectUrl);
      await injectContentScripts(tab.id);
      await smartDelay(500);

      const detailResult = await sendTabMessage(tab.id, { action: 'scrapeProjectDetails' });
      if (!detailResult?.success) {
        log(`⚠ Failed to extract details`, 'warning');
        continue;
      }

      const details = detailResult.details;

      // Generate proposal via backend proxy (API key hidden server-side)
      let proposal = '';
      try {
        log('🤖 Generating AI proposal...', 'info');
        proposal = await generateProposalViaBackend(
          { title: details.title || project.title, description: details.description, skills: details.skills },
          settings.aiPersona || 'professional freelancer'
        );
        log('✅ Proposal generated', 'success');
      } catch (err) {
        log(`⚠ AI error: ${err.message}. Using fallback.`, 'warning');
        proposal = fallbackProposal({ title: details.title || project.title });
      }

      // Calculate bid
      const budgetStr = details.budget || '$500';
      const parsedBudget = parseBudgetRange(budgetStr);
      const baseBudget = parsedBudget.min === parsedBudget.max ? parsedBudget.min : Math.floor((parsedBudget.min + parsedBudget.max) / 2);
      const bidAmount = Math.max(1, Math.floor(baseBudget * (1 - (settings.budgetReduction || 10) / 100)));
      const baseDays = parseInt(details.deliveryDays) || 7;
      const bidDays = Math.max(1, Math.ceil(baseDays * (1 - (settings.daysReduction || 20) / 100)));

      log(`📝 Bid: $${bidAmount} | ${bidDays} days`, 'info');

      const fillResult = await sendTabMessage(tab.id, {
        action: 'fillBidForm',
        data: { amount: bidAmount, days: bidDays, proposal }
      });

      if (fillResult?.success) {
        const f = fillResult.filled;
        log(`✏️ Filled — Amt:${f.amount ? '✓' : '✗'} Days:${f.days ? '✓' : '✗'} Prop:${f.proposal ? '✓' : '✗'}`, 'info');
      }

      if (settings.autoSubmit) {
        await smartDelay(500);
        const submitResult = await sendTabMessage(tab.id, { action: 'submitBid' });
        if (submitResult?.success) {
          log('✅ Bid submitted!', 'success');
          bidCount++;
          await markProjectProcessed(project.projectId);
          updateStat('bidsPlaced');
          broadcastStats();
          
          // Notify backend of processed bid
          try {
            const usageRes = await ApiClient.recordBidProcessed(project.projectId, project.title, true);
            if (usageRes.success && usageRes.usage) {
              chrome.runtime.sendMessage({ action: 'usageUpdate', data: usageRes.usage }).catch(() => {});
            }
          } catch (err) {
            log(`⚠ Failed to sync usage with server: ${err.message}`, 'warning');
          }
        } else {
          log('⚠ Submit button not found or click failed', 'warning');
        }
      } else {
        log('⏸ Auto-submit OFF — review manually', 'warning');
        bidCount++;
        await markProjectProcessed(project.projectId);
        updateStat('bidsPlaced');
        broadcastStats();
        
        // Notify backend of processed bid (even if manual review, it is processed)
        try {
          const usageRes = await ApiClient.recordBidProcessed(project.projectId, project.title, false);
          if (usageRes.success && usageRes.usage) {
            chrome.runtime.sendMessage({ action: 'usageUpdate', data: usageRes.usage }).catch(() => {});
          }
        } catch (err) {
          log(`⚠ Failed to sync usage with server: ${err.message}`, 'warning');
        }
      }

      // Configurable delay between bids (keeps a human-like pace)
      const delayMs = (settings.delayBetweenBids || 5) * 1000;
      await smartDelay(delayMs);
    }

    currentPage++;
    if (currentPage > 100) break;
  }

  if (bidCount >= maxBids) log(`🎯 Max bids reached (${bidCount})`, 'success');
}

// ===== Backend AI Proxy =====
async function generateProposalViaBackend(project, persona) {
  // Use ApiClient to handle the request to Apps Script
  const result = await ApiClient.generateProposal(project, persona);

  if (!result.success) {
    if (result.status === 401 || result.code === 'AUTH_REQUIRED') {
      throw new Error('Session expired. Please login again.');
    }
    if (result.status === 429 || result.error?.includes('limit')) {
      throw new Error(result.error || 'Usage limit reached.');
    }
    throw new Error(result.error || 'AI service error');
  }

  // Broadcast usage update to popup
  if (result._usageInfo) {
    chrome.runtime.sendMessage({ action: 'usageUpdate', data: result._usageInfo }).catch(() => {});
  }

  return result.proposal || '';
}

function fallbackProposal(project) {
  return `Hello,\n\nI am interested in your project "${project.title}". I have relevant experience and can deliver high-quality work within your timeline.\n\nLooking forward to working with you.\n\nBest regards`;
}

// ===== Helpers =====
function parseKeywords(s) {
  if (!s) return [];
  return s.split(/[,\n]+/).map(k => k.trim().toLowerCase()).filter(k => k.length > 0);
}

function filterByKeywords(projects, keywords) {
  if (keywords.length === 0) return projects;
  return projects.filter(p => {
    const text = `${p.title} ${p.description} ${(p.skills || []).join(' ')}`.toLowerCase();
    return keywords.some(kw => text.includes(kw));
  });
}

function parseBudgetRange(s) {
  if (!s) return { min: 500, max: 500 };
  const nums = s.replace(/,/g, '').match(/[\d.]+/g);
  if (!nums || !nums.length) return { min: 500, max: 500 };
  const vals = nums.map(Number);
  return vals.length === 1 ? { min: vals[0], max: vals[0] } : { min: vals[0], max: vals[1] };
}

/**
 * Smart delay — shorter than original humanDelay, just enough
 * for DOM to settle. Used only where truly needed.
 */
function smartDelay(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// ===== Tab Navigation =====
async function navigateToUrl(url) {
  return new Promise(resolve => {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      if (tabs[0]) chrome.tabs.update(tabs[0].id, { url }, tab => resolve(tab));
      else chrome.tabs.create({ url }, tab => resolve(tab));
    });
  });
}

/**
 * Navigate a tab to a URL and wait for it to finish loading.
 * Includes a timeout to prevent hanging forever.
 */
async function navigateTabToUrl(tabId, url) {
  return new Promise((resolve, reject) => {
    const TIMEOUT_MS = 30000;
    let settled = false;

    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        chrome.tabs.onUpdated.removeListener(listener);
        resolve(null); // resolve with null instead of rejecting — loop continues
      }
    }, TIMEOUT_MS);

    function listener(id, info) {
      if (id === tabId && info.status === 'complete' && !settled) {
        settled = true;
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        chrome.tabs.get(tabId, tab => resolve(tab));
      }
    }

    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.update(tabId, { url });
  });
}

/**
 * Wait for a tab to finish loading (status === 'complete').
 * Used after navigateToUrl which doesn't wait for load.
 */
function waitForTabLoad(tabId, timeout = 15000) {
  return new Promise(resolve => {
    let settled = false;

    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        chrome.tabs.onUpdated.removeListener(listener);
        resolve(); // don't block on timeout
      }
    }, timeout);

    function listener(id, info) {
      if (id === tabId && info.status === 'complete' && !settled) {
        settled = true;
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }

    // Check if already complete
    chrome.tabs.get(tabId, tab => {
      if (tab?.status === 'complete' && !settled) {
        settled = true;
        clearTimeout(timer);
        resolve();
      } else {
        chrome.tabs.onUpdated.addListener(listener);
      }
    });
  });
}

async function injectContentScripts(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['utils/storage.js', 'utils/scraper.js', 'utils/calculator.js', 'content.js'],
    });
  } catch (err) { /* may already be injected */ }
}

async function sendTabMessage(tabId, message) {
  return new Promise(resolve => {
    try {
      chrome.tabs.sendMessage(tabId, message, response => {
        if (chrome.runtime.lastError) resolve(null);
        else resolve(response);
      });
    } catch { resolve(null); }
  });
}

// ===== Storage =====
async function getProcessedProjects() {
  return new Promise(r => chrome.storage.local.get('processedProjects', d => r(d.processedProjects || {})));
}

async function markProjectProcessed(id) {
  const p = await getProcessedProjects();
  p[id] = Date.now();
  return new Promise(r => chrome.storage.local.set({ processedProjects: p }, r));
}

async function updateStat(field, value) {
  return new Promise(resolve => {
    chrome.storage.local.get('stats', r => {
      const stats = r.stats || { bidsPlaced: 0, projectsScanned: 0, successRate: 0 };
      stats[field] = typeof value === 'number' ? (stats[field] || 0) + value : (stats[field] || 0) + 1;
      if (stats.projectsScanned > 0) stats.successRate = Math.round((stats.bidsPlaced / stats.projectsScanned) * 100);
      chrome.storage.local.set({ stats }, resolve);
    });
  });
}

// ===== Broadcast =====
function log(message, type = 'info') {
  console.log(`[AutoBidder] ${message}`);
  chrome.runtime.sendMessage({ action: 'log', data: { message, type, timestamp: new Date().toLocaleTimeString() } }).catch(() => {});
}

function broadcastStatus(status) {
  chrome.runtime.sendMessage({ action: 'statusUpdate', data: { status, bidCount, currentPage } }).catch(() => {});
}

function broadcastStats() {
  chrome.storage.local.get('stats', r => {
    chrome.runtime.sendMessage({ action: 'statsUpdate', data: r.stats || {} }).catch(() => {});
  });
}

// ===== Keepalive (only when automation is running) =====
chrome.alarms.create('keepalive', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'keepalive' && isRunning) {
    console.log('[AutoBidder] keepalive — automation active');
  }
});
