/**
 * content.js — Content Script for freelancer.pk
 * Injected into all freelancer.pk pages.
 * Listens for messages from background.js and performs DOM operations.
 */

(function () {
  'use strict';

  // Prevent double-injection
  if (window.__autobidder_content_loaded) return;
  window.__autobidder_content_loaded = true;

  /**
   * Wait for a DOM element to appear using MutationObserver.
   * Resolves as soon as the element exists — no arbitrary delays.
   */
  function waitForElement(selector, timeout = 10000) {
    return new Promise((resolve, reject) => {
      // Check if it already exists
      const existing = document.querySelector(selector);
      if (existing) return resolve(existing);

      let settled = false;
      const observer = new MutationObserver(() => {
        const el = document.querySelector(selector);
        if (el && !settled) {
          settled = true;
          observer.disconnect();
          clearTimeout(timer);
          resolve(el);
        }
      });

      observer.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true,
      });

      const timer = setTimeout(() => {
        if (!settled) {
          settled = true;
          observer.disconnect();
          reject(new Error(`Element "${selector}" not found within ${timeout}ms`));
        }
      }, timeout);
    });
  }

  /**
   * Wait for document to be interactive/complete.
   * Much faster than a hard delay when the page is already loaded.
   */
  function waitForDocReady() {
    return new Promise(resolve => {
      if (document.readyState === 'complete' || document.readyState === 'interactive') {
        resolve();
      } else {
        document.addEventListener('DOMContentLoaded', resolve, { once: true });
      }
    });
  }

  /**
   * Listen for messages from background script
   */
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.action) {
      case 'scrapeProjects':
        handleScrapeProjects(sendResponse);
        return true; // async response

      case 'scrapeProjectDetails':
        handleScrapeDetails(sendResponse);
        return true;

      case 'fillBidForm':
        handleFillForm(message.data, sendResponse);
        return true;

      case 'submitBid':
        handleSubmitBid(sendResponse);
        return true;

      case 'ping':
        sendResponse({ status: 'alive' });
        return false; // sync response

      default:
        return false;
    }
  });

  /**
   * Handle scraping project cards from listing page
   */
  async function handleScrapeProjects(sendResponse) {
    try {
      await waitForDocReady();

      // Wait for at least one project link to appear in the DOM
      try {
        await waitForElement('a[href*="/projects/"]', 10000);
      } catch (e) {
        // Page might have loaded but no projects — that's fine, scraper handles empty results
      }

      const projects = Scraper.scrapeProjectCards();
      sendResponse({ success: true, projects });
    } catch (err) {
      sendResponse({ success: false, error: err.message });
    }
  }

  /**
   * Handle scraping project details from detail page
   */
  async function handleScrapeDetails(sendResponse) {
    try {
      await waitForDocReady();

      // Wait for the title element to confirm the page rendered
      try {
        await waitForElement('h1', 8000);
      } catch (e) {
        // Continue anyway — the element might have a different selector
      }

      const details = Scraper.scrapeProjectDetails();
      sendResponse({ success: true, details });
    } catch (err) {
      sendResponse({ success: false, error: err.message });
    }
  }

  /**
   * Handle filling the bid form
   */
  async function handleFillForm(bidData, sendResponse) {
    try {
      await waitForDocReady();

      // Wait for any input/textarea to be present (bid form rendered)
      try {
        await waitForElement('input, textarea', 5000);
      } catch (e) {
        // Continue — fillBidForm does its own field matching
      }

      const result = await Scraper.fillBidForm(bidData);
      sendResponse({ success: true, filled: result });
    } catch (err) {
      sendResponse({ success: false, error: err.message });
    }
  }

  /**
   * Handle clicking the submit button
   */
  async function handleSubmitBid(sendResponse) {
    try {
      await waitForDocReady();

      // Wait briefly for submit button to be present
      try {
        await waitForElement('button, input[type="submit"]', 3000);
      } catch (e) {
        // Continue — clickSubmitBid scans all buttons
      }

      const clicked = Scraper.clickSubmitBid();
      sendResponse({ success: !!clicked }); // ensure boolean
    } catch (err) {
      sendResponse({ success: false, error: err.message });
    }
  }

  console.log('[AutoBidder] Content script loaded on', window.location.href);
})();
