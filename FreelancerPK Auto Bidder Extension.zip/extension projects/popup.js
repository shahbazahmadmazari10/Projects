/**
 * popup.js — SaaS Dashboard Logic
 * Manages authentication, view routing, subscription display,
 * usage tracking, settings, and automation controls.
 */

document.addEventListener('DOMContentLoaded', () => {
  // ===== Views =====
  const views = {
    loading: document.getElementById('viewLoading'),
    login: document.getElementById('viewLogin'),
    register: document.getElementById('viewRegister'),
    dashboard: document.getElementById('viewDashboard'),
    account: document.getElementById('viewAccount'),
    plans: document.getElementById('viewPlans'),
  };

  // ===== DOM Elements — Auth =====
  const loginForm = document.getElementById('loginForm');
  const loginEmail = document.getElementById('loginEmail');
  const loginPassword = document.getElementById('loginPassword');
  const loginError = document.getElementById('loginError');
  const loginBtn = document.getElementById('loginBtn');
  const loginLoader = document.getElementById('loginLoader');

  const registerForm = document.getElementById('registerForm');
  const registerName = document.getElementById('registerName');
  const registerEmail = document.getElementById('registerEmail');
  const registerPassword = document.getElementById('registerPassword');
  const registerError = document.getElementById('registerError');
  const registerBtn = document.getElementById('registerBtn');
  const registerLoader = document.getElementById('registerLoader');

  // ===== DOM Elements — Dashboard =====
  const statusBadge = document.getElementById('statusBadge');
  const statusText = document.getElementById('statusText');
  const planBadgeHeader = document.getElementById('planBadgeHeader');
  const avatarInitial = document.getElementById('avatarInitial');
  const subPlanIcon = document.getElementById('subPlanIcon');
  const subPlanName = document.getElementById('subPlanName');
  const subPlanExpiry = document.getElementById('subPlanExpiry');
  const subBanner = document.getElementById('subBanner');
  const usageWarning = document.getElementById('usageWarning');
  const usageWarningText = document.getElementById('usageWarningText');

  // Usage gauges
  const dailyGaugeFill = document.getElementById('dailyGaugeFill');
  const dailyGaugeValue = document.getElementById('dailyGaugeValue');
  const monthlyGaugeFill = document.getElementById('monthlyGaugeFill');
  const monthlyGaugeValue = document.getElementById('monthlyGaugeValue');
  const autoGaugeFill = document.getElementById('autoGaugeFill');
  const autoGaugeValue = document.getElementById('autoGaugeValue');

  // Controls
  const btnStart = document.getElementById('btnStart');
  const btnStop = document.getElementById('btnStop');
  const statBids = document.getElementById('statBids');
  const statScanned = document.getElementById('statScanned');
  const statRate = document.getElementById('statRate');

  // Settings
  const inputPersona = document.getElementById('inputPersona');
  const inputKeywords = document.getElementById('inputKeywords');
  const inputBudgetReduction = document.getElementById('inputBudgetReduction');
  const inputDaysReduction = document.getElementById('inputDaysReduction');
  const inputMaxBids = document.getElementById('inputMaxBids');
  const inputDelay = document.getElementById('inputDelay');
  const toggleAutoSubmit = document.getElementById('toggleAutoSubmit');
  const autoSubmitLock = document.getElementById('autoSubmitLock');

  // Log
  const logEntries = document.getElementById('logEntries');
  const logCount = document.getElementById('logCount');
  const btnClearLog = document.getElementById('btnClearLog');

  // Account view
  const accountAvatar = document.getElementById('accountAvatar');
  const accountName = document.getElementById('accountName');
  const accountEmail = document.getElementById('accountEmail');
  const accountPlan = document.getElementById('accountPlan');
  const accountStatus = document.getElementById('accountStatus');
  const accountExpiry = document.getElementById('accountExpiry');
  const accountDailyUsage = document.getElementById('accountDailyUsage');
  const accountMonthlyUsage = document.getElementById('accountMonthlyUsage');
  const accountAutoRuns = document.getElementById('accountAutoRuns');

  // Plans view
  const plansGrid = document.getElementById('plansGrid');

  let logMessages = [];
  let currentUser = null;
  let currentPlan = null;
  let currentUsage = null;

  // ===== INITIALIZATION =====
  initialize();

  async function initialize() {
    showView('loading');

    const loggedIn = await AuthManager.isLoggedIn();
    if (!loggedIn) {
      showView('login');
      return;
    }

    // Fetch profile from server
    const result = await ApiClient.getProfile();
    if (!result.success) {
      showView('login');
      return;
    }

    currentUser = result.user;
    currentPlan = result.plan;
    currentUsage = result.usage;

    // Load settings and stats in parallel for faster popup open
    await Promise.all([loadSettings(), loadStats()]);
    updateDashboard();
    checkRunningStatus();
    showView('dashboard');
  }

  // ===== VIEW ROUTING =====
  function showView(name) {
    Object.values(views).forEach((v) => v.classList.add('hidden'));
    if (views[name]) {
      views[name].classList.remove('hidden');
    }
  }

  // ===== AUTH — LOGIN =====
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    loginError.classList.add('hidden');
    loginBtn.disabled = true;
    loginLoader.classList.remove('hidden');

    const result = await ApiClient.login(
      loginEmail.value.trim(),
      loginPassword.value
    );

    loginBtn.disabled = false;
    loginLoader.classList.add('hidden');

    if (!result.success) {
      loginError.textContent = result.error || 'Login failed';
      loginError.classList.remove('hidden');
      return;
    }

    currentUser = result.user;
    currentPlan = result.plan;

    // Fetch usage after login
    const usageResult = await ApiClient.getUsageStats();
    if (usageResult.success) currentUsage = usageResult.usage;

    loadSettings();
    loadStats();
    updateDashboard();
    checkRunningStatus();
    showView('dashboard');
  });

  // ===== AUTH — REGISTER =====
  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    registerError.classList.add('hidden');
    registerBtn.disabled = true;
    registerLoader.classList.remove('hidden');

    const result = await ApiClient.register(
      registerName.value.trim(),
      registerEmail.value.trim(),
      registerPassword.value
    );

    registerBtn.disabled = false;
    registerLoader.classList.add('hidden');

    if (!result.success) {
      registerError.textContent = result.error || 'Registration failed';
      registerError.classList.remove('hidden');
      return;
    }

    currentUser = result.user;
    currentPlan = result.plan;
    currentUsage = { dailyUsage: 0, monthlyUsage: 0, automationRuns: 0 };

    loadSettings();
    updateDashboard();
    showView('dashboard');
  });

  // ===== AUTH — View Switching =====
  document.getElementById('showRegister').addEventListener('click', () => showView('register'));
  document.getElementById('showLogin').addEventListener('click', () => showView('login'));

  // ===== DASHBOARD UPDATES =====
  function updateDashboard() {
    if (!currentUser) return;

    // Set avatar and header
    const initial = (currentUser.name || currentUser.email || 'U')[0].toUpperCase();
    avatarInitial.textContent = initial;

    // Subscription banner
    if (currentPlan) {
      const planColor = currentPlan.color || '#64748b';
      planBadgeHeader.textContent = currentPlan.displayName || currentPlan.name || 'Free Plan';
      planBadgeHeader.style.color = planColor;
      subPlanIcon.textContent = currentPlan.icon || '🆓';
      subPlanName.textContent = currentPlan.displayName || currentPlan.name || 'Free Plan';
      subBanner.style.borderLeftColor = planColor;

      // Expiry
      if (currentUser.expiryDate) {
        const expiry = new Date(currentUser.expiryDate);
        const daysLeft = Math.ceil((expiry - new Date()) / (1000 * 60 * 60 * 24));
        subPlanExpiry.textContent = daysLeft > 0
          ? `${daysLeft} days remaining`
          : 'Expired';
        if (daysLeft <= 7 && daysLeft > 0) {
          subPlanExpiry.style.color = '#f59e0b';
        } else if (daysLeft <= 0) {
          subPlanExpiry.style.color = '#ef4444';
        }
      }

      // Feature locks
      if (currentPlan.features) {
        if (!currentPlan.features.autoSubmit) {
          toggleAutoSubmit.disabled = true;
          toggleAutoSubmit.checked = false;
          autoSubmitLock.classList.remove('hidden');
        } else {
          toggleAutoSubmit.disabled = false;
          autoSubmitLock.classList.add('hidden');
        }

        // Enforce min delay
        if (currentPlan.limits && currentPlan.limits.minDelaySeconds) {
          inputDelay.min = currentPlan.limits.minDelaySeconds;
          if (parseInt(inputDelay.value) < currentPlan.limits.minDelaySeconds) {
            inputDelay.value = currentPlan.limits.minDelaySeconds;
          }
        }

        // Enforce max bids
        if (currentPlan.limits && currentPlan.limits.maxBidsPerRun) {
          inputMaxBids.max = currentPlan.limits.maxBidsPerRun;
          if (parseInt(inputMaxBids.value) > currentPlan.limits.maxBidsPerRun) {
            inputMaxBids.value = currentPlan.limits.maxBidsPerRun;
          }
        }
      }
    }

    // Usage gauges
    updateUsageGauges();
  }

  async function refreshProfile() {
    const result = await ApiClient.getProfile();
    if (result.success) {
      currentUser = result.user;
      currentPlan = result.plan;
      currentUsage = result.usage;
      updateDashboard();
    }
    return result;
  }

  function updateUsageGauges() {
    if (!currentUsage) return;

    const dailyUsed = currentUsage.dailyUsage || 0;
    const dailyLimit = currentUsage.dailyLimit || 10;
    const monthlyUsed = currentUsage.monthlyUsage || 0;
    const monthlyLimit = currentUsage.monthlyLimit || 100;
    const autoRuns = currentUsage.automationRuns || 0;
    const autoLimit = currentUsage.dailyAutomationLimit || 5;

    setGauge(dailyGaugeFill, dailyGaugeValue, dailyUsed, dailyLimit);
    setGauge(monthlyGaugeFill, monthlyGaugeValue, monthlyUsed, monthlyLimit);
    setGauge(autoGaugeFill, autoGaugeValue, autoRuns, autoLimit);

    // Warning banner
    const dailyPct = dailyLimit > 0 ? dailyUsed / dailyLimit : 0;
    const monthlyPct = monthlyLimit > 0 ? monthlyUsed / monthlyLimit : 0;

    if (dailyPct >= 1 || monthlyPct >= 1) {
      usageWarning.classList.remove('hidden');
      usageWarningText.textContent = 'Usage limit reached. Upgrade your plan for more.';
      usageWarning.classList.add('danger');
    } else if (dailyPct >= 0.8 || monthlyPct >= 0.8) {
      usageWarning.classList.remove('hidden');
      usageWarningText.textContent = 'Approaching usage limit. Consider upgrading.';
      usageWarning.classList.remove('danger');
    } else {
      usageWarning.classList.add('hidden');
    }
  }

  function setGauge(fillEl, valueEl, used, limit) {
    const circumference = 2 * Math.PI * 34;
    const percentage = limit > 0 ? Math.min(used / limit, 1) : 0;
    const offset = circumference * (1 - percentage);

    fillEl.style.strokeDasharray = circumference;
    fillEl.style.strokeDashoffset = offset;

    // Color based on percentage
    if (percentage >= 0.9) {
      fillEl.style.stroke = '#ef4444';
    } else if (percentage >= 0.7) {
      fillEl.style.stroke = '#f59e0b';
    } else {
      fillEl.style.stroke = '';
    }

    valueEl.textContent = `${used}/${limit}`;
  }

  // ===== AUTOMATION CONTROLS =====
  btnStart.addEventListener('click', async () => {
    const profileResult = await refreshProfile();
    if (!profileResult.success) {
      addLog('⚠ Could not refresh profile. Please login again.', 'error');
      return;
    }

    const settings = gatherSettings();
    saveSettings(settings);

    // Check usage before starting
    const usageResult = await ApiClient.getUsageStats();
    if (usageResult.success) {
      currentUsage = usageResult.usage;
      updateUsageGauges();

      if (usageResult.usage.dailyUsage >= usageResult.usage.dailyLimit) {
        addLog('❌ Daily usage limit reached. Upgrade your plan.', 'error');
        return;
      }

      if (usageResult.usage.automationRuns >= usageResult.usage.dailyAutomationLimit) {
        addLog('❌ Daily automation runs limit reached. Upgrade your plan.', 'error');
        return;
      }
    }

    chrome.runtime.sendMessage(
      { action: 'startAutomation', settings },
      (response) => {
        if (chrome.runtime.lastError) {
          addLog('⚠ Could not connect to background service', 'warning');
          return;
        }
        if (response?.success) {
          setRunningState(true);
          addLog('🚀 Automation started', 'success');
        }
      }
    );
  });

  btnStop.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'stopAutomation' }, (response) => {
      if (chrome.runtime.lastError) return;
      if (response?.success) {
        setRunningState(false);
        addLog('⏹ Automation stopped', 'warning');
      }
    });
  });

  // ===== SECTION TOGGLES =====
  document.querySelectorAll('.section-toggle').forEach((btn) => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-target');
      const target = document.getElementById(targetId);
      if (target) {
        target.classList.toggle('collapsed');
        btn.textContent = target.classList.contains('collapsed') ? '▸' : '▾';
      }
    });
  });

  // ===== CLEAR LOG =====
  btnClearLog.addEventListener('click', () => {
    logMessages = [];
    renderLogs();
  });

  // ===== AUTO-SAVE SETTINGS =====
  const settingInputs = [
    inputPersona, inputKeywords, inputBudgetReduction,
    inputDaysReduction, inputMaxBids, inputDelay, toggleAutoSubmit,
  ];

  settingInputs.forEach((input) => {
    const event = input.type === 'checkbox' ? 'change' : 'input';
    input.addEventListener(event, () => {
      saveSettings(gatherSettings());
    });
  });

  // ===== ACCOUNT VIEW =====
  document.getElementById('btnAccount').addEventListener('click', async () => {
    if (!currentUser) return;

    await refreshProfile();

    const initial = (currentUser.name || 'U')[0].toUpperCase();
    accountAvatar.textContent = initial;
    accountName.textContent = currentUser.name || 'User';
    accountEmail.textContent = currentUser.email || '';
    accountPlan.textContent = currentPlan?.displayName || currentPlan?.name || 'Free';
    accountStatus.textContent = currentUser.status || 'active';

    if (currentUser.expiryDate) {
      accountExpiry.textContent = new Date(currentUser.expiryDate).toLocaleDateString();
    }

    // Refresh usage
    const usageResult = await ApiClient.getUsageStats();
    if (usageResult.success) {
      currentUsage = usageResult.usage;
      accountDailyUsage.textContent = `${currentUsage.dailyUsage || 0} / ${currentUsage.dailyLimit || 10}`;
      accountMonthlyUsage.textContent = `${currentUsage.monthlyUsage || 0} / ${currentUsage.monthlyLimit || 100}`;
      accountAutoRuns.textContent = currentUsage.automationRuns || 0;
    }

    showView('account');
  });

  document.getElementById('btnBackFromAccount').addEventListener('click', () => {
    showView('dashboard');
  });

  document.getElementById('btnLogout').addEventListener('click', async () => {
    await ApiClient.logout();
    currentUser = null;
    currentPlan = null;
    currentUsage = null;
    showView('login');
  });

  // ===== PLANS VIEW =====
  document.getElementById('btnUpgrade').addEventListener('click', () => loadPlansView());
  document.getElementById('btnViewPlans').addEventListener('click', () => loadPlansView());
  document.getElementById('btnUpgradeAccount').addEventListener('click', () => loadPlansView());

  document.getElementById('btnBackFromPlans').addEventListener('click', () => {
    showView('dashboard');
  });

  async function loadPlansView() {
    await refreshProfile();
    const result = await ApiClient.getPlans();
    if (!result.success) {
      addLog('⚠ Could not load plans', 'warning');
      return;
    }

    plansGrid.innerHTML = '';
    result.plans.forEach((plan) => {
      const isCurrentPlan = currentUser?.plan === plan.id;
      const card = document.createElement('div');
      card.className = `plan-card ${isCurrentPlan ? 'current' : ''}`;
      card.style.borderTopColor = plan.color;

      card.innerHTML = `
        <div class="plan-card-header">
          <span class="plan-card-icon">${plan.icon}</span>
          <span class="plan-card-name" style="color: ${plan.color}">${plan.name}</span>
        </div>
        <div class="plan-card-price">
          ${plan.price === 0 ? 'Free' : `$${plan.price}<span class="plan-card-period">/mo</span>`}
        </div>
        <div class="plan-card-desc">${plan.description}</div>
        <ul class="plan-card-features">
          <li>📊 ${plan.limits.dailyApiRequests >= 999999 ? 'Unlimited' : plan.limits.dailyApiRequests} daily requests</li>
          <li>📈 ${plan.limits.monthlyApiRequests >= 999999 ? 'Unlimited' : plan.limits.monthlyApiRequests} monthly requests</li>
          <li>🤖 ${plan.limits.dailyAutomationRuns >= 999999 ? 'Unlimited' : plan.limits.dailyAutomationRuns} automation runs/day</li>
          <li>🎯 Up to ${plan.limits.maxBidsPerRun} bids per run</li>
          <li>⚡ Min ${plan.limits.minDelaySeconds}s delay</li>
          ${plan.features.autoSubmit ? '<li>✅ Auto Submit</li>' : '<li class="locked">🔒 Auto Submit</li>'}
          ${plan.features.customPersona ? '<li>✅ Custom Persona</li>' : '<li class="locked">🔒 Custom Persona</li>'}
          ${plan.features.keywordFiltering ? '<li>✅ Keyword Filtering</li>' : '<li class="locked">🔒 Keyword Filtering</li>'}
        </ul>
        <button class="plan-card-btn ${isCurrentPlan ? 'current' : ''}" 
                data-plan="${plan.id}" ${isCurrentPlan ? 'disabled' : ''}>
          ${isCurrentPlan ? 'Current Plan' : 'Select Plan'}
        </button>
      `;

      // Upgrade button handler
      const btn = card.querySelector('.plan-card-btn');
      if (!isCurrentPlan) {
        btn.addEventListener('click', async () => {
          const result = await ApiClient.requestUpgrade(plan.id);
          if (result.success) {
            addLog(`⭐ Upgrade requested: ${plan.name}`, 'success');
            alert(result.message);
          } else {
            addLog(`⚠ ${result.error}`, 'warning');
          }
        });
      }

      plansGrid.appendChild(card);
    });

    showView('plans');
  }

  // ===== LISTEN FOR BACKGROUND MESSAGES =====
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.action) {
      case 'log':
        addLog(message.data.message, message.data.type);
        break;
      case 'statusUpdate':
        setRunningState(message.data.status === 'running');
        break;
      case 'statsUpdate':
        updateStatsDisplay(message.data);
        break;
      case 'usageUpdate':
        if (message.data) {
          currentUsage = { ...currentUsage, ...message.data };
          updateUsageGauges();
        }
        break;
    }
    return false; // sync — prevents 'message port closed' warnings
  });

  // ===== HELPER FUNCTIONS =====

  function gatherSettings() {
    return {
      aiPersona: inputPersona.value.trim() || 'professional freelancer',
      keywords: inputKeywords.value.trim(),
      budgetReduction: parseInt(inputBudgetReduction.value) || 10,
      daysReduction: parseInt(inputDaysReduction.value) || 20,
      maxBids: parseInt(inputMaxBids.value) || 15,
      delayBetweenBids: parseInt(inputDelay.value) || 5,
      autoSubmit: toggleAutoSubmit.checked,
    };
  }

  function saveSettings(settings) {
    chrome.storage.local.set({ settings });
  }

  function loadSettings() {
    return new Promise(resolve => {
      chrome.storage.local.get('settings', (result) => {
        const s = result.settings || {};
        if (s.aiPersona) inputPersona.value = s.aiPersona;
        if (s.keywords) inputKeywords.value = s.keywords;
        if (s.budgetReduction !== undefined) inputBudgetReduction.value = s.budgetReduction;
        if (s.daysReduction !== undefined) inputDaysReduction.value = s.daysReduction;
        if (s.maxBids !== undefined) inputMaxBids.value = s.maxBids;
        if (s.delayBetweenBids !== undefined) inputDelay.value = s.delayBetweenBids;
        if (s.autoSubmit !== undefined) toggleAutoSubmit.checked = s.autoSubmit;
        resolve();
      });
    });
  }

  function loadStats() {
    return new Promise(resolve => {
      chrome.storage.local.get('stats', (result) => {
        updateStatsDisplay(result.stats || {});
        resolve();
      });
    });
  }

  function updateStatsDisplay(stats) {
    statBids.textContent = stats.bidsPlaced || 0;
    statScanned.textContent = stats.projectsScanned || 0;
    statRate.textContent = `${stats.successRate || 0}%`;
  }

  function checkRunningStatus() {
    chrome.runtime.sendMessage({ action: 'getStatus' }, (response) => {
      if (chrome.runtime.lastError) return;
      if (response?.isRunning) {
        setRunningState(true);
      }
    });
  }

  function setRunningState(running) {
    if (running) {
      btnStart.disabled = true;
      btnStop.disabled = false;
      statusBadge.className = 'status-badge running';
      statusText.textContent = 'Running';
    } else {
      btnStart.disabled = false;
      btnStop.disabled = true;
      statusBadge.className = 'status-badge idle';
      statusText.textContent = 'Idle';
    }
  }

  function addLog(message, type = 'info') {
    const time = new Date().toLocaleTimeString('en-US', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });

    logMessages.push({ time, message, type });
    if (logMessages.length > 100) {
      logMessages = logMessages.slice(-100);
    }
    renderLogs();
  }

  function renderLogs() {
    logCount.textContent = logMessages.length;

    if (logMessages.length === 0) {
      logEntries.innerHTML = '<div class="log-empty">No activity yet — press Start to begin</div>';
      return;
    }

    logEntries.innerHTML = logMessages
      .slice()
      .reverse()
      .map(
        (entry) =>
          `<div class="log-entry ${entry.type}">
            <span class="log-time">${entry.time}</span>
            <span class="log-msg">${escapeHtml(entry.message)}</span>
          </div>`
      )
      .join('');
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
});
