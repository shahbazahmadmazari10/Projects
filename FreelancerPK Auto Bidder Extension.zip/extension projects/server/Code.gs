/**
 * FreelancerPK Auto Bidder - Google Apps Script Backend
 * 
 * Instructions:
 * 1. Open your Google Sheet
 * 2. Go to Extensions > Apps Script
 * 3. Paste this entire code into Code.gs
 * 4. Go to Project Settings (gear icon) > Script Properties
 * 5. Add Property: XAI_API_KEY = your_xai_api_key
 * 6. Add Property: ADMIN_EMAIL = your_email@example.com
 * 7. Click "Deploy" > "New deployment"
 * 8. Type: "Web app"
 * 9. Execute as: "Me", Access: "Anyone"
 * 10. Click "Deploy" and copy the Web App URL.
 */

// ===== CONSTANTS & CONFIG =====
const SHEET_NAMES = {
  USERS: 'Users',
  USAGE_LOGS: 'UsageLogs',
  LOGIN_HISTORY: 'LoginHistory'
};

const SUBSCRIPTION_PLANS = {
  free: {
    id: 'free', displayName: 'Free Plan', color: '#64748b', icon: '🆓', price: 0, currency: 'USD',
    limits: { dailyApiRequests: 10, monthlyApiRequests: 100, dailyAutomationRuns: 5, maxBidsPerRun: 5, minDelaySeconds: 8 },
    features: { aiProposals: true, keywordFiltering: false, budgetOptimization: false, autoSubmit: false, priorityProcessing: false, customPersona: false, activityExport: false },
    description: 'Get started with limited daily usage and basic features.'
  },
  basic: {
    id: 'basic', displayName: 'Basic Plan', color: '#3b82f6', icon: '⭐', price: 9.99, currency: 'USD',
    limits: { dailyApiRequests: 50, monthlyApiRequests: 1000, dailyAutomationRuns: 25, maxBidsPerRun: 15, minDelaySeconds: 5 },
    features: { aiProposals: true, keywordFiltering: true, budgetOptimization: true, autoSubmit: false, priorityProcessing: false, customPersona: true, activityExport: false },
    description: 'Medium usage with keyword filtering and budget tools.'
  },
  pro: {
    id: 'pro', displayName: 'Pro Plan', color: '#8b5cf6', icon: '🚀', price: 29.99, currency: 'USD',
    limits: { dailyApiRequests: 200, monthlyApiRequests: 5000, dailyAutomationRuns: 100, maxBidsPerRun: 50, minDelaySeconds: 3 },
    features: { aiProposals: true, keywordFiltering: true, budgetOptimization: true, autoSubmit: true, priorityProcessing: true, customPersona: true, activityExport: true },
    description: 'Full features with auto-submit and priority processing.'
  },
  enterprise: {
    id: 'enterprise', displayName: 'Enterprise Plan', color: '#f59e0b', icon: '👑', price: 99.99, currency: 'USD',
    limits: { dailyApiRequests: 999999, monthlyApiRequests: 999999, dailyAutomationRuns: 999999, maxBidsPerRun: 999, minDelaySeconds: 1 },
    features: { aiProposals: true, keywordFiltering: true, budgetOptimization: true, autoSubmit: true, priorityProcessing: true, customPersona: true, activityExport: true },
    description: 'Unlimited access with custom limits and dedicated support.'
  }
};

const USER_STATUS = { ACTIVE: 'active', BLOCKED: 'blocked', SUSPENDED: 'suspended', EXPIRED: 'expired' };
const USER_ROLES = { USER: 'user', ADMIN: 'admin' };

// ===== ENTRY POINT =====
function doPost(e) {
  try {
    ensureSetup();
    
    // Handle CORS preflight (if triggered by some environments, though Apps Script handles basic CORS)
    if (e.postData === undefined) {
      return response({ success: false, error: 'No data received' }, 400);
    }

    const body = JSON.parse(e.postData.contents);
    const action = body.action || (e.parameter && e.parameter.action);
    const token = body.token;
    
    // Auth-free routes
    if (action === 'register') return handleRegister(body);
    if (action === 'login') return handleLogin(body, getClientIp(e));
    if (action === 'health') return response({ status: 'ok', service: 'FreelancerPK Apps Script API' });
    if (action === 'getPlans') return handleGetPlans();

    // Require Auth
    if (!token) return response({ success: false, error: 'Authentication required', code: 'AUTH_REQUIRED' }, 401);
    const user = getUserByToken(token);
    if (!user) return response({ success: false, error: 'Invalid or expired token', code: 'INVALID_TOKEN' }, 401);
    if (user.status === USER_STATUS.BLOCKED) return response({ success: false, error: 'Account blocked' }, 403);

    // Update last active
    checkAndResetUsage(user);

    // Routes with Auth
    if (action === 'me') return handleMe(user);
    if (action === 'logout') return handleLogout(user);
    if (action === 'generateAI') return handleGenerateAI(body, user);
    if (action === 'getUsageStats') return handleGetUsageStats(user);
    if (action === 'getUsageHistory') return handleGetUsageHistory(user);
    if (action === 'getCurrentSubscription') return handleGetCurrentSubscription(user);
    if (action === 'requestUpgrade') return handleRequestUpgrade(body, user);
    if (action === 'recordBidProcessed') return handleRecordBidProcessed(body, user);

    // Admin Routes
    if (action.startsWith('admin_')) {
      if (user.role !== USER_ROLES.ADMIN) return response({ success: false, error: 'Admin access required' }, 403);
      if (action === 'admin_getUsers') return handleAdminGetUsers();
      if (action === 'admin_getUser') return handleAdminGetUser(body.userId);
      if (action === 'admin_updateUserStatus') return handleAdminUpdateUserStatus(body);
      if (action === 'admin_updateUserPlan') return handleAdminUpdateUserPlan(body);
      if (action === 'admin_getStats') return handleAdminGetStats();
    }

    return response({ success: false, error: 'Unknown action' }, 400);

  } catch (error) {
    return response({ success: false, error: error.toString() }, 500);
  }
}

// Support for GET requests (mostly for health check or testing)
function doGet(e) {
  ensureSetup();
  return response({ 
    status: 'ok', 
    service: 'FreelancerPK Apps Script API', 
    message: 'Please use POST requests with JSON payload containing an "action" field.' 
  });
}

function response(data, statusCode = 200) {
  // Apps Script doesn't let you set arbitrary status codes easily in ContentService, 
  // but we can embed it in the JSON.
  data.status = statusCode;
  return ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

// ===== SETUP & DB HELPERS =====
function ensureSetup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  
  const requiredSheets = [
    { name: SHEET_NAMES.USERS, headers: ['UserID', 'Name', 'Email', 'PasswordHash', 'Plan', 'Status', 'ExpiryDate', 'DailyUsage', 'MonthlyUsage', 'DailyLimit', 'MonthlyLimit', 'AutomationRuns', 'LastLogin', 'LastIP', 'LastDevice', 'SessionToken', 'Role', 'CreatedAt', 'Features', 'LastReset', 'RequestedPlan', 'ApplicationStatus'] },
    { name: SHEET_NAMES.USAGE_LOGS, headers: ['UserID', 'Timestamp', 'Type', 'Details'] },
    { name: SHEET_NAMES.LOGIN_HISTORY, headers: ['UserID', 'Timestamp', 'IP', 'Device', 'Success'] }
  ];

  requiredSheets.forEach(sheetDef => {
    let sheet = ss.getSheetByName(sheetDef.name);
    if (!sheet) {
      sheet = ss.insertSheet(sheetDef.name);
      sheet.appendRow(sheetDef.headers);
      sheet.getRange(1, 1, 1, sheetDef.headers.length).setFontWeight("bold");
    } else {
      // Sheet exists, check if any headers are missing case-insensitively
      const rawExistingHeaders = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
      const existingHeaders = rawExistingHeaders.map(h => String(h).trim().toLowerCase().replace(/\s+/g, ''));
      
      const missingHeaders = sheetDef.headers.filter(h => {
        const normH = String(h).trim().toLowerCase().replace(/\s+/g, '');
        return existingHeaders.indexOf(normH) === -1;
      });
      
      if (missingHeaders.length > 0) {
        const startCol = rawExistingHeaders.length + 1;
        const headerRange = sheet.getRange(1, startCol, 1, missingHeaders.length);
        headerRange.setValues([missingHeaders]);
        headerRange.setFontWeight("bold");
      }
    }
  });
}

function generateId() {
  return Utilities.getUuid();
}

function getClientIp(e) {
  // Apps script doesn't easily expose IP, using dummy
  return 'apps-script-client'; 
}

function hashPassword(password) {
  // Very basic SHA-256 for Apps Script. In production, use salt.
  const rawHash = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, password);
  return rawHash.map(b => (b < 0 ? b + 256 : b).toString(16).padStart(2, '0')).join('');
}

// ===== USER DB OPS =====
function getUsersSheet() { return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAMES.USERS); }

function getAllUsers() {
  const sheet = getUsersSheet();
  const data = sheet.getDataRange().getValues();
  if (data.length <= 1) return [];
  
  const rawHeaders = data[0];
  
  // Map normalized lower-case headers to standard casing properties used in Code.gs
  const keyMapping = {
    userid: 'UserID', name: 'Name', email: 'Email', passwordhash: 'PasswordHash',
    plan: 'Plan', status: 'Status', expirydate: 'ExpiryDate',
    dailyusage: 'DailyUsage', monthlyusage: 'MonthlyUsage',
    dailylimit: 'DailyLimit', monthlylimit: 'MonthlyLimit',
    automationruns: 'AutomationRuns', lastlogin: 'LastLogin',
    lastip: 'LastIP', lastdevice: 'LastDevice', sessiontoken: 'SessionToken',
    role: 'Role', createdat: 'CreatedAt', features: 'Features', lastreset: 'LastReset',
    requestedplan: 'RequestedPlan', applicationstatus: 'ApplicationStatus'
  };
  
  const users = [];
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    const user = {};
    
    // Initialize standard keys with empty defaults to avoid undefined
    Object.values(keyMapping).forEach(k => { user[k] = ''; });
    
    row.forEach((val, idx) => {
      const rawHeader = rawHeaders[idx];
      if (rawHeader) {
        const normHeader = String(rawHeader).trim().toLowerCase().replace(/\s+/g, '');
        const standardKey = keyMapping[normHeader];
        if (standardKey) {
          user[standardKey] = val;
        } else {
          user[rawHeader] = val; // Custom headers fallback
        }
      }
    });
    user._rowIndex = i + 1;
    users.push(user);
  }
  return users;
}

function getUserByEmail(email) {
  const users = getAllUsers();
  return users.find(u => String(u.Email).toLowerCase() === String(email).toLowerCase()) || null;
}

function getUserByToken(token) {
  if (!token) return null;
  const users = getAllUsers();
  return users.find(u => u.SessionToken === token) || null;
}

function saveUserUpdates(user, updates) {
  const sheet = getUsersSheet();
  const rawHeaders = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const headers = rawHeaders.map(h => String(h).trim().toLowerCase().replace(/\s+/g, ''));
  
  Object.keys(updates).forEach(key => {
    const normKey = String(key).trim().toLowerCase().replace(/\s+/g, '');
    const colIndex = headers.indexOf(normKey) + 1;
    if (colIndex > 0) {
      sheet.getRange(user._rowIndex, colIndex).setValue(updates[key]);
      user[key] = updates[key]; // Update local object
    }
  });
}

function sanitizeUser(user) {
  const safe = { ...user };
  delete safe.PasswordHash;
  delete safe.SessionToken;
  delete safe._rowIndex;
  try { safe.Features = typeof safe.Features === 'string' ? JSON.parse(safe.Features) : safe.Features; } catch(e) { safe.Features = {}; }
  return safe;
}

function normalizePlanKey(planKey) {
  return String(planKey || '').trim().toLowerCase();
}

function getPlanByIdOrName(planKey) {
  const normalized = normalizePlanKey(planKey);
  if (!normalized) return SUBSCRIPTION_PLANS.free;
  if (SUBSCRIPTION_PLANS[normalized]) return SUBSCRIPTION_PLANS[normalized];
  const fallback = Object.values(SUBSCRIPTION_PLANS).find((plan) => {
    return normalizePlanKey(plan.displayName) === normalized;
  });
  return fallback || SUBSCRIPTION_PLANS.free;
}

function syncUserPlanFields(user) {
  const plan = getPlanByIdOrName(user.Plan);
  const updates = {};

  if (!user.Plan || normalizePlanKey(user.Plan) !== normalizePlanKey(plan.id)) {
    updates.Plan = plan.id;
  }

  if (Number(user.DailyLimit) !== plan.limits.dailyApiRequests) {
    updates.DailyLimit = plan.limits.dailyApiRequests;
  }

  if (Number(user.MonthlyLimit) !== plan.limits.monthlyApiRequests) {
    updates.MonthlyLimit = plan.limits.monthlyApiRequests;
  }

  const existingFeatures = typeof user.Features === 'string' ? user.Features : JSON.stringify(user.Features);
  const expectedFeatures = JSON.stringify(plan.features);
  if (existingFeatures !== expectedFeatures) {
    updates.Features = expectedFeatures;
  }

  if (Object.keys(updates).length > 0) {
    saveUserUpdates(user, updates);
  }

  return plan;
}

// ===== AUTH ROUTES =====
function handleRegister(body) {
  const { name, email, password } = body;
  if (!name || !email || !password || password.length < 6) {
    return response({ success: false, error: 'Invalid input' }, 400);
  }

  if (getUserByEmail(email)) {
    return response({ success: false, error: 'Email exists' }, 409);
  }

  const allUsers = getAllUsers();
  const adminEmail = PropertiesService.getScriptProperties().getProperty('ADMIN_EMAIL') || '';
  const isAdmin = allUsers.length === 0 || email.toLowerCase() === adminEmail.toLowerCase();

  const sheet = getUsersSheet();
  const plan = SUBSCRIPTION_PLANS.free;
  const now = new Date();
  const expiry = new Date();
  expiry.setDate(expiry.getDate() + 30);
  const token = generateId();

  const newRow = [
    generateId(), name, email.toLowerCase(), hashPassword(password), 'free', USER_STATUS.ACTIVE, 
    expiry.toISOString(), 0, 0, plan.limits.dailyApiRequests, plan.limits.monthlyApiRequests, 
    0, now.toISOString(), 'unknown', 'unknown', token, isAdmin ? USER_ROLES.ADMIN : USER_ROLES.USER, 
    now.toISOString(), JSON.stringify(plan.features), now.toISOString(), '', ''
  ];
  
  sheet.appendRow(newRow);
  const newUser = getUserByEmail(email); // Fetch back to get proper object
  
  logLogin(newUser.UserID, 'unknown', 'unknown', true);
  
  return response({
    success: true,
    token: token,
    user: sanitizeUser(newUser),
    plan: { ...plan, features: plan.features }
  });
}

function handleLogin(body, ip) {
  const { email, password } = body;
  const user = getUserByEmail(email);
  
  if (!user || user.PasswordHash !== hashPassword(password)) {
    if(user) logLogin(user.UserID, ip, 'unknown', false);
    return response({ success: false, error: 'Invalid credentials' }, 401);
  }

  const token = generateId();
  saveUserUpdates(user, {
    SessionToken: token,
    LastLogin: new Date().toISOString(),
    LastIP: ip
  });

  logLogin(user.UserID, ip, 'unknown', true);
  
  const plan = SUBSCRIPTION_PLANS[user.Plan] || SUBSCRIPTION_PLANS.free;
  return response({
    success: true,
    token: token,
    user: sanitizeUser(user),
    plan: { ...plan, features: plan.features }
  });
}

function handleMe(user) {
  const plan = SUBSCRIPTION_PLANS[user.Plan] || SUBSCRIPTION_PLANS.free;
  return response({
    success: true,
    user: sanitizeUser(user),
    plan: { ...plan, features: plan.features },
    usage: getUsageObject(user)
  });
}

function handleLogout(user) {
  saveUserUpdates(user, { SessionToken: '' });
  return response({ success: true });
}

// ===== USAGE & LOGGING =====
function logLogin(userId, ip, device, success) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAMES.LOGIN_HISTORY);
  sheet.appendRow([userId, new Date().toISOString(), ip, device, success ? 'true' : 'false']);
}

function logUsage(userId, type, details) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAMES.USAGE_LOGS);
  sheet.appendRow([userId, new Date().toISOString(), type, details]);
}

function checkAndResetUsage(user) {
  // Check if there is an approved upgrade request
  if (user.ApplicationStatus && String(user.ApplicationStatus).trim().toLowerCase() === 'approved') {
    const reqPlan = user.RequestedPlan ? String(user.RequestedPlan).trim().toLowerCase() : '';
    if (reqPlan && SUBSCRIPTION_PLANS[reqPlan] && String(user.Plan).toLowerCase() !== reqPlan) {
      const p = SUBSCRIPTION_PLANS[reqPlan];
      saveUserUpdates(user, {
        Plan: reqPlan,
        DailyLimit: p.limits.dailyApiRequests,
        MonthlyLimit: p.limits.monthlyApiRequests,
        Features: JSON.stringify(p.features)
      });
      logUsage(user.UserID, 'plan_upgraded', `Upgraded to ${p.displayName} via spreadsheet approval`);
    }
  }

  syncUserPlanFields(user);

  const now = new Date();
  const lastReset = user.LastReset ? new Date(user.LastReset) : new Date(0);
  const updates = {};
  
  if (now.toDateString() !== lastReset.toDateString()) {
    updates.DailyUsage = 0;
    updates.AutomationRuns = 0;
    updates.LastReset = now.toISOString();
  }
  
  if (now.getMonth() !== lastReset.getMonth() || now.getFullYear() !== lastReset.getFullYear()) {
    updates.MonthlyUsage = 0;
  }
  
  if (Object.keys(updates).length > 0) {
    saveUserUpdates(user, updates);
  }
}

function getUsageObject(user) {
  const plan = getPlanByIdOrName(user.Plan);
  return {
    dailyUsage: Number(user.DailyUsage) || 0,
    monthlyUsage: Number(user.MonthlyUsage) || 0,
    automationRuns: Number(user.AutomationRuns) || 0,
    dailyLimit: Number(user.DailyLimit) || plan.limits.dailyApiRequests,
    monthlyLimit: Number(user.MonthlyLimit) || plan.limits.monthlyApiRequests,
    dailyAutomationLimit: plan.limits.dailyAutomationRuns,
    maxBidsPerRun: plan.limits.maxBidsPerRun
  };
}

// ===== AI PROXY =====
function handleGenerateAI(body, user) {
  const { project, persona } = body;
  
  const usage = getUsageObject(user);
  if (usage.dailyUsage >= usage.dailyLimit) {
    return response({ success: false, error: 'Daily API limit reached' }, 429);
  }

  // Increment Usage immediately for the proposal generation request
  const newDaily = (Number(user.DailyUsage) || 0) + 1;
  const newMonthly = (Number(user.MonthlyUsage) || 0) + 1;
  saveUserUpdates(user, {
    DailyUsage: newDaily,
    MonthlyUsage: newMonthly
  });

  const plan = SUBSCRIPTION_PLANS[user.Plan] || SUBSCRIPTION_PLANS.free;
  const effectivePersona = plan.features.customPersona ? (persona || 'professional freelancer') : 'professional freelancer';

  const apiKey = PropertiesService.getScriptProperties().getProperty('XAI_API_KEY');
  if (!apiKey) {
    // Fallback if no API key is configured
    const fallbackText = `Hello,\n\nI am interested in your project "${project.title}". I have relevant experience and can deliver high-quality work within your timeline.\n\nLooking forward to working with you.\n\nBest regards`;
    logUsage(user.UserID, 'api_request_fallback', `Generated fallback proposal (no API key configured) for ${project.title}`);
    return response({
      success: true,
      proposal: fallbackText,
      fallback: true,
      message: 'Used fallback proposal (no API key configured on server)',
      _usageInfo: getUsageObject(user)
    });
  }
  
  let systemPrompt = `You are a ${effectivePersona} on Freelancer.pk.\nYour task is to write a short, professional freelancing proposal.\nRules:\n- Keep it under 150 words\n- Professional yet friendly tone\n- Mention relevant experience briefly\n- Highlight fast delivery\n- Show understanding of the project requirements\n- Do NOT use markdown formatting\n- Do NOT include greetings like "Dear Sir/Madam"\n- Start with "Hi," or "Hello,"\n- End with a brief call to action`;
  
  let userPrompt = `Write a proposal for this project:\n\nProject Title: ${project.title}\n\n`;
  if (project.description) userPrompt += `Project Description:\n${project.description.substring(0, 1000)}\n\n`;
  if (project.skills) userPrompt += `Required Skills: ${Array.isArray(project.skills) ? project.skills.join(', ') : project.skills}\n`;

  try {
    const fetchOptions = {
      method: 'post',
      contentType: 'application/json',
      headers: { 'Authorization': `Bearer ${apiKey}` },
      payload: JSON.stringify({
        model: 'grok-3-mini', // or whatever you configure
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        temperature: 0.7,
        max_tokens: 512
      }),
      muteHttpExceptions: true
    };
    
    const apiResponse = UrlFetchApp.fetch('https://api.x.ai/v1/chat/completions', fetchOptions);
    const apiCode = apiResponse.getResponseCode();
    const data = JSON.parse(apiResponse.getContentText());
    
    if (apiCode !== 200) {
      throw new Error(data.error?.message || 'AI API Error');
    }

    let proposal = data.choices[0].message.content || '';
    proposal = proposal.replace(/```[\s\S]*?```/g, '').replace(/\*\*/g, '').replace(/\*/g, '').replace(/#{1,6}\s/g, '').replace(/---/g, '').trim();
    proposal = proposal.replace(/^(Subject|Proposal|Title|Re):.*\n/im, '').trim();

    logUsage(user.UserID, 'api_request', `Generated proposal for ${project.title}`);

    return response({
      success: true,
      proposal: proposal,
      fallback: false,
      _usageInfo: getUsageObject(user)
    });

  } catch (e) {
    // Fallback on fetch/API error
    const fallbackText = `Hello,\n\nI am interested in your project "${project.title}". I have relevant experience and can deliver high-quality work within your timeline.\n\nLooking forward to working with you.\n\nBest regards`;
    logUsage(user.UserID, 'api_request_fallback', `Generated fallback proposal due to error: ${e.message}`);
    return response({
      success: true,
      proposal: fallbackText,
      fallback: true,
      message: 'Used fallback due to API error: ' + e.message,
      _usageInfo: getUsageObject(user)
    });
  }
}

// ===== SUBSCRIPTION & USAGE =====
function handleGetUsageStats(user) {
  const stats = getUsageObject(user);
  const plan = SUBSCRIPTION_PLANS[user.Plan] || SUBSCRIPTION_PLANS.free;
  return response({
    success: true,
    usage: {
      ...stats,
      plan: user.Plan,
      planName: plan.displayName,
      dailyRemaining: Math.max(0, stats.dailyLimit - stats.dailyUsage),
      monthlyRemaining: Math.max(0, stats.monthlyLimit - stats.monthlyUsage),
      dailyPercentage: stats.dailyLimit > 0 ? Math.round((stats.dailyUsage / stats.dailyLimit) * 100) : 0,
      monthlyPercentage: stats.monthlyLimit > 0 ? Math.round((stats.monthlyUsage / stats.monthlyLimit) * 100) : 0,
    }
  });
}

function handleGetUsageHistory(user) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAMES.LOGIN_HISTORY);
  const data = sheet.getDataRange().getValues();
  const history = [];
  for(let i=data.length-1; i>0; i--) {
    if(data[i][0] === user.UserID) {
      history.push({ userId: data[i][0], timestamp: data[i][1], ip: data[i][2], device: data[i][3], success: data[i][4] === 'true' });
      if(history.length >= 20) break;
    }
  }
  const plan = SUBSCRIPTION_PLANS[user.Plan] || SUBSCRIPTION_PLANS.free;
  return response({ success: true, history: history, plan: plan.displayName });
}

function handleGetPlans() {
  const plans = Object.values(SUBSCRIPTION_PLANS).map(p => ({
    id: p.id, name: p.displayName, color: p.color, icon: p.icon, price: p.price,
    currency: p.currency, limits: p.limits, features: p.features, description: p.description
  }));
  return response({ success: true, plans: plans });
}

function handleGetCurrentSubscription(user) {
  const plan = SUBSCRIPTION_PLANS[user.Plan] || SUBSCRIPTION_PLANS.free;
  return response({
    success: true,
    subscription: {
      plan: plan.id, planName: plan.displayName, color: plan.color, icon: plan.icon,
      price: plan.price, status: user.Status, expiryDate: user.ExpiryDate,
      limits: plan.limits, features: plan.features, usage: getUsageObject(user)
    }
  });
}

function handleRequestUpgrade(body, user) {
  const reqPlan = body.plan;
  if (!SUBSCRIPTION_PLANS[reqPlan]) return response({ success: false, error: 'Invalid plan' }, 400);
  
  // Record requested plan and set status to Pending in spreadsheet
  saveUserUpdates(user, {
    RequestedPlan: reqPlan,
    ApplicationStatus: 'Pending'
  });
  
  logUsage(user.UserID, 'upgrade_request', `${user.Plan} -> ${reqPlan} (Pending approval)`);
  const p = SUBSCRIPTION_PLANS[reqPlan];
  return response({
    success: true,
    message: `Upgrade request for ${p.displayName} submitted successfully. Your request is currently pending admin approval from the spreadsheet.`,
    requestedPlan: p.displayName,
    price: p.price,
    currency: p.currency
  });
}

// ===== ADMIN ROUTES =====
function handleAdminGetUsers() {
  const users = getAllUsers().map(u => sanitizeUser(u));
  return response({ success: true, users: users, total: users.length, active: users.filter(u=>u.Status === USER_STATUS.ACTIVE).length });
}

function handleAdminGetUser(userId) {
  const u = getAllUsers().find(x => x.UserID === userId);
  if(!u) return response({success:false, error:'Not found'}, 404);
  return response({ success: true, user: sanitizeUser(u) });
}

function handleAdminUpdateUserStatus(body) {
  const { userId, status } = body;
  const u = getAllUsers().find(x => x.UserID === userId);
  if(!u) return response({success:false, error:'Not found'}, 404);
  saveUserUpdates(u, { Status: status });
  return response({ success: true, message: 'Status updated' });
}

function handleAdminUpdateUserPlan(body) {
  const { userId, plan } = body;
  const u = getAllUsers().find(x => x.UserID === userId);
  if(!u) return response({success:false, error:'Not found'}, 404);
  const p = SUBSCRIPTION_PLANS[plan];
  if(!p) return response({success:false, error:'Invalid plan'}, 400);
  
  saveUserUpdates(u, {
    Plan: plan,
    DailyLimit: p.limits.dailyApiRequests,
    MonthlyLimit: p.limits.monthlyApiRequests,
    Features: JSON.stringify(p.features)
  });
  return response({ success: true, message: 'Plan updated' });
}

function handleAdminGetStats() {
  const users = getAllUsers();
  const stats = {
    totalUsers: users.length,
    activeUsers: users.filter((u) => u.Status === USER_STATUS.ACTIVE).length,
    totalDailyUsage: users.reduce((sum, u) => sum + (Number(u.DailyUsage) || 0), 0),
    totalMonthlyUsage: users.reduce((sum, u) => sum + (Number(u.MonthlyUsage) || 0), 0),
  };
  return response({ success: true, stats: stats });
}

function handleRecordBidProcessed(body, user) {
  checkAndResetUsage(user);
  
  const plan = SUBSCRIPTION_PLANS[user.Plan] || SUBSCRIPTION_PLANS.free;
  const usage = getUsageObject(user);
  
  if (user.Status !== USER_STATUS.ACTIVE) {
    return response({ success: false, error: 'Account is inactive' }, 403);
  }
  
  // Increment AutomationRuns
  const currentRuns = Number(user.AutomationRuns) || 0;
  saveUserUpdates(user, {
    AutomationRuns: currentRuns + 1
  });
  
  logUsage(user.UserID, 'automation_run', `Processed bid for project: ${body.title || 'Unknown'} (ID: ${body.projectId || 'Unknown'})`);
  
  return response({
    success: true,
    usage: getUsageObject(user)
  });
}
