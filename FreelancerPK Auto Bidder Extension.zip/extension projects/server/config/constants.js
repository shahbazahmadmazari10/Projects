/**
 * constants.js — Subscription Plans & System Constants
 * Defines all plan tiers, usage limits, and system configuration.
 */

const SUBSCRIPTION_PLANS = {
  free: {
    id: 'free',
    name: 'Free',
    displayName: 'Free Plan',
    color: '#64748b',
    icon: '🆓',
    price: 0,
    currency: 'USD',
    billingCycle: 'monthly',
    limits: {
      dailyApiRequests: 10,
      monthlyApiRequests: 100,
      dailyAutomationRuns: 5,
      maxBidsPerRun: 5,
      minDelaySeconds: 8,
    },
    features: {
      aiProposals: true,
      keywordFiltering: false,
      budgetOptimization: false,
      autoSubmit: false,
      priorityProcessing: false,
      customPersona: false,
      activityExport: false,
    },
    description: 'Get started with limited daily usage and basic features.',
  },

  basic: {
    id: 'basic',
    name: 'Basic',
    displayName: 'Basic Plan',
    color: '#3b82f6',
    icon: '⭐',
    price: 9.99,
    currency: 'USD',
    billingCycle: 'monthly',
    limits: {
      dailyApiRequests: 50,
      monthlyApiRequests: 1000,
      dailyAutomationRuns: 25,
      maxBidsPerRun: 15,
      minDelaySeconds: 5,
    },
    features: {
      aiProposals: true,
      keywordFiltering: true,
      budgetOptimization: true,
      autoSubmit: false,
      priorityProcessing: false,
      customPersona: true,
      activityExport: false,
    },
    description: 'Medium usage with keyword filtering and budget tools.',
  },

  pro: {
    id: 'pro',
    name: 'Pro',
    displayName: 'Pro Plan',
    color: '#8b5cf6',
    icon: '🚀',
    price: 29.99,
    currency: 'USD',
    billingCycle: 'monthly',
    limits: {
      dailyApiRequests: 200,
      monthlyApiRequests: 5000,
      dailyAutomationRuns: 100,
      maxBidsPerRun: 50,
      minDelaySeconds: 3,
    },
    features: {
      aiProposals: true,
      keywordFiltering: true,
      budgetOptimization: true,
      autoSubmit: true,
      priorityProcessing: true,
      customPersona: true,
      activityExport: true,
    },
    description: 'Full features with auto-submit and priority processing.',
  },

  enterprise: {
    id: 'enterprise',
    name: 'Enterprise',
    displayName: 'Enterprise Plan',
    color: '#f59e0b',
    icon: '👑',
    price: 99.99,
    currency: 'USD',
    billingCycle: 'monthly',
    limits: {
      dailyApiRequests: 999999,
      monthlyApiRequests: 999999,
      dailyAutomationRuns: 999999,
      maxBidsPerRun: 999,
      minDelaySeconds: 1,
    },
    features: {
      aiProposals: true,
      keywordFiltering: true,
      budgetOptimization: true,
      autoSubmit: true,
      priorityProcessing: true,
      customPersona: true,
      activityExport: true,
    },
    description: 'Unlimited access with custom limits and dedicated support.',
  },
};

// Google Sheet column mapping (0-indexed)
const SHEET_COLUMNS = {
  USERS: {
    USER_ID: 0,         // A
    NAME: 1,            // B
    EMAIL: 2,           // C
    PASSWORD_HASH: 3,   // D
    PLAN: 4,            // E
    STATUS: 5,          // F
    EXPIRY_DATE: 6,     // G
    DAILY_USAGE: 7,     // H
    MONTHLY_USAGE: 8,   // I
    DAILY_LIMIT: 9,     // J
    MONTHLY_LIMIT: 10,  // K
    AUTOMATION_RUNS: 11,// L
    LAST_LOGIN: 12,     // M
    LAST_IP: 13,        // N
    LAST_DEVICE: 14,    // O
    SESSION_HASH: 15,   // P
    ROLE: 16,           // Q
    CREATED_AT: 17,     // R
    FEATURES: 18,       // S
    LAST_RESET: 19,     // T
  },
  USAGE_LOGS: {
    USER_ID: 0,
    TIMESTAMP: 1,
    TYPE: 2,
    DETAILS: 3,
  },
  LOGIN_HISTORY: {
    USER_ID: 0,
    TIMESTAMP: 1,
    IP: 2,
    DEVICE: 3,
    SUCCESS: 4,
  },
};

const SHEET_NAMES = {
  USERS: 'Users',
  USAGE_LOGS: 'UsageLogs',
  LOGIN_HISTORY: 'LoginHistory',
};

// User statuses
const USER_STATUS = {
  ACTIVE: 'active',
  BLOCKED: 'blocked',
  SUSPENDED: 'suspended',
  EXPIRED: 'expired',
};

// User roles
const USER_ROLES = {
  USER: 'user',
  ADMIN: 'admin',
};

// AI Model configuration
const AI_CONFIG = {
  API_URL: 'https://api.x.ai/v1/chat/completions',
  MODEL: 'grok-3-mini',
  MAX_TOKENS: 512,
  TEMPERATURE: 0.7,
};

module.exports = {
  SUBSCRIPTION_PLANS,
  SHEET_COLUMNS,
  SHEET_NAMES,
  USER_STATUS,
  USER_ROLES,
  AI_CONFIG,
};
