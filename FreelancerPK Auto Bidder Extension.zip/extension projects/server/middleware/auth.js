/**
 * auth.js — JWT Authentication Middleware
 * Verifies JWT tokens and attaches user data to requests.
 */

const { verifyToken } = require('../utils/jwt');
const googleSheets = require('../services/googleSheets');
const logger = require('../utils/logger');
const { USER_STATUS } = require('../config/constants');

/**
 * Require valid JWT token for protected routes
 */
async function requireAuth(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        error: 'Authentication required',
        code: 'AUTH_REQUIRED',
      });
    }

    const token = authHeader.split(' ')[1];
    let decoded;

    try {
      decoded = verifyToken(token);
    } catch (err) {
      if (err.name === 'TokenExpiredError') {
        return res.status(401).json({
          error: 'Token expired. Please login again.',
          code: 'TOKEN_EXPIRED',
        });
      }
      return res.status(401).json({
        error: 'Invalid token',
        code: 'INVALID_TOKEN',
      });
    }

    // Fetch user from database
    const user = await googleSheets.getUserById(decoded.userId);
    if (!user) {
      return res.status(401).json({
        error: 'User not found',
        code: 'USER_NOT_FOUND',
      });
    }

    // Check if account is active
    if (user.status === USER_STATUS.BLOCKED) {
      return res.status(403).json({
        error: 'Your account has been blocked. Contact support.',
        code: 'ACCOUNT_BLOCKED',
      });
    }

    if (user.status === USER_STATUS.SUSPENDED) {
      return res.status(403).json({
        error: 'Your account is suspended. Contact support.',
        code: 'ACCOUNT_SUSPENDED',
      });
    }

    // Check expiry
    if (user.expiryDate) {
      const expiry = new Date(user.expiryDate);
      if (expiry < new Date()) {
        return res.status(403).json({
          error: 'Your subscription has expired. Please renew.',
          code: 'SUBSCRIPTION_EXPIRED',
          expiryDate: user.expiryDate,
        });
      }
    }

    // Attach user to request
    req.user = user;
    req.userId = user.userId;
    next();
  } catch (err) {
    logger.error('AuthMiddleware', 'Authentication error', { error: err.message });
    return res.status(500).json({
      error: 'Authentication service error',
      code: 'AUTH_ERROR',
    });
  }
}

/**
 * Require admin role
 */
async function requireAdmin(req, res, next) {
  // requireAuth must be called first
  if (!req.user) {
    return res.status(401).json({
      error: 'Authentication required',
      code: 'AUTH_REQUIRED',
    });
  }

  if (req.user.role !== 'admin') {
    logger.warn('AuthMiddleware', `Non-admin access attempt by ${req.user.email}`);
    return res.status(403).json({
      error: 'Admin access required',
      code: 'ADMIN_REQUIRED',
    });
  }

  next();
}

module.exports = { requireAuth, requireAdmin };
