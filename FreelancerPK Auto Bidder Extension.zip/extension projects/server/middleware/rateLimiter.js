/**
 * rateLimiter.js — Rate Limiting Middleware
 * Protects against abuse and brute-force attacks.
 */

const rateLimit = require('express-rate-limit');

/**
 * General API rate limiter
 */
const generalLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutes
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: 'Too many requests. Please try again later.',
    code: 'RATE_LIMITED',
    retryAfter: '15 minutes',
  },
});

/**
 * Strict rate limiter for auth routes (login/register)
 */
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: parseInt(process.env.AUTH_RATE_LIMIT_MAX) || 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: 'Too many authentication attempts. Please try again in 15 minutes.',
    code: 'AUTH_RATE_LIMITED',
  },
});

/**
 * AI endpoint rate limiter (per-user, based on plan)
 */
const aiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 10, // 10 requests per minute max regardless of plan
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: 'AI request rate exceeded. Please slow down.',
    code: 'AI_RATE_LIMITED',
  },
});

module.exports = { generalLimiter, authLimiter, aiLimiter };
