/**
 * usageTracker.js — Usage Tracking & Limit Enforcement Middleware
 * Checks and increments usage counters. Blocks when limits exceeded.
 */

const googleSheets = require('../services/googleSheets');
const { SUBSCRIPTION_PLANS } = require('../config/constants');
const logger = require('../utils/logger');

/**
 * Track API usage and enforce limits
 * Must be used AFTER requireAuth middleware
 */
async function trackApiUsage(req, res, next) {
  try {
    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: 'Authentication required', code: 'AUTH_REQUIRED' });
    }

    const plan = SUBSCRIPTION_PLANS[user.plan] || SUBSCRIPTION_PLANS.free;
    const stats = await googleSheets.getUsageStats(user.userId);
    if (!stats) {
      return res.status(500).json({ error: 'Could not fetch usage data', code: 'USAGE_ERROR' });
    }

    // Check daily limit
    if (stats.dailyUsage >= stats.dailyLimit) {
      logger.warn('UsageTracker', `Daily limit reached for ${user.email}`, {
        usage: stats.dailyUsage,
        limit: stats.dailyLimit,
      });
      return res.status(429).json({
        error: 'Daily usage limit reached. Upgrade your plan for more.',
        code: 'DAILY_LIMIT_REACHED',
        usage: stats.dailyUsage,
        limit: stats.dailyLimit,
        plan: user.plan,
      });
    }

    // Check monthly limit
    if (stats.monthlyUsage >= stats.monthlyLimit) {
      logger.warn('UsageTracker', `Monthly limit reached for ${user.email}`);
      return res.status(429).json({
        error: 'Monthly usage limit reached. Upgrade your plan for more.',
        code: 'MONTHLY_LIMIT_REACHED',
        usage: stats.monthlyUsage,
        limit: stats.monthlyLimit,
        plan: user.plan,
      });
    }

    // Add usage warning headers
    const dailyRemaining = stats.dailyLimit - stats.dailyUsage;
    const monthlyRemaining = stats.monthlyLimit - stats.monthlyUsage;

    res.setHeader('X-Daily-Usage', stats.dailyUsage);
    res.setHeader('X-Daily-Limit', stats.dailyLimit);
    res.setHeader('X-Daily-Remaining', dailyRemaining);
    res.setHeader('X-Monthly-Usage', stats.monthlyUsage);
    res.setHeader('X-Monthly-Limit', stats.monthlyLimit);
    res.setHeader('X-Monthly-Remaining', monthlyRemaining);

    // Warn if approaching limits (80% used)
    if (dailyRemaining <= Math.ceil(stats.dailyLimit * 0.2)) {
      res.setHeader('X-Usage-Warning', 'approaching_daily_limit');
    }
    if (monthlyRemaining <= Math.ceil(stats.monthlyLimit * 0.2)) {
      res.setHeader('X-Usage-Warning', 'approaching_monthly_limit');
    }

    // Increment usage counter
    await googleSheets.incrementUsage(user.userId, 'api');

    // Attach usage info to request for downstream use
    req.usage = stats;
    req.planConfig = plan;

    next();
  } catch (err) {
    logger.error('UsageTracker', 'Error tracking usage', { error: err.message });
    // Don't block the request on tracking errors — just log
    next();
  }
}

/**
 * Track automation run usage
 */
async function trackAutomationUsage(req, res, next) {
  try {
    const user = req.user;
    if (!user) return next();

    const plan = SUBSCRIPTION_PLANS[user.plan] || SUBSCRIPTION_PLANS.free;
    const stats = await googleSheets.getUsageStats(user.userId);
    if (!stats) return next();

    if (stats.automationRuns >= plan.limits.dailyAutomationRuns) {
      return res.status(429).json({
        error: 'Daily automation limit reached. Upgrade for more runs.',
        code: 'AUTOMATION_LIMIT_REACHED',
        usage: stats.automationRuns,
        limit: plan.limits.dailyAutomationRuns,
      });
    }

    await googleSheets.incrementUsage(user.userId, 'automation');
    next();
  } catch (err) {
    logger.error('UsageTracker', 'Error tracking automation', { error: err.message });
    next();
  }
}

module.exports = { trackApiUsage, trackAutomationUsage };
