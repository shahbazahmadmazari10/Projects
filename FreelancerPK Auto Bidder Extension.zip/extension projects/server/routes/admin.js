/**
 * admin.js — Admin Control Routes
 * Full admin panel API for managing users, subscriptions, and usage.
 */

const express = require('express');
const router = express.Router();
const { requireAuth, requireAdmin } = require('../middleware/auth');
const googleSheets = require('../services/googleSheets');
const { SUBSCRIPTION_PLANS, USER_STATUS } = require('../config/constants');
const logger = require('../utils/logger');

// All admin routes require auth + admin role
router.use(requireAuth, requireAdmin);

/**
 * GET /api/admin/users
 * List all users with their stats
 */
router.get('/users', async (req, res) => {
  try {
    const users = await googleSheets.getUsers();
    const sanitized = users.map((u) => googleSheets.sanitizeUser(u));

    res.json({
      success: true,
      users: sanitized,
      total: sanitized.length,
      active: sanitized.filter((u) => u.status === USER_STATUS.ACTIVE).length,
      blocked: sanitized.filter((u) => u.status === USER_STATUS.BLOCKED).length,
    });
  } catch (err) {
    logger.error('Admin', 'Error fetching users', { error: err.message });
    res.status(500).json({ error: 'Failed to fetch users', code: 'ADMIN_ERROR' });
  }
});

/**
 * GET /api/admin/users/:id
 * Get detailed info for a specific user
 */
router.get('/users/:id', async (req, res) => {
  try {
    const user = await googleSheets.getUserById(req.params.id);
    if (!user) {
      return res.status(404).json({ error: 'User not found', code: 'NOT_FOUND' });
    }

    const loginHistory = await googleSheets.getLoginHistory(req.params.id, 20);

    res.json({
      success: true,
      user: googleSheets.sanitizeUser(user),
      loginHistory,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch user details', code: 'ADMIN_ERROR' });
  }
});

/**
 * PUT /api/admin/users/:id/status
 * Activate, deactivate, block, or suspend a user
 */
router.put('/users/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    const validStatuses = Object.values(USER_STATUS);

    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        error: `Invalid status. Must be one of: ${validStatuses.join(', ')}`,
        code: 'INVALID_STATUS',
      });
    }

    const user = await googleSheets.updateUser(req.params.id, { status });
    if (!user) {
      return res.status(404).json({ error: 'User not found', code: 'NOT_FOUND' });
    }

    logger.info('Admin', `User status updated: ${user.email} → ${status}`, { adminEmail: req.user.email });

    res.json({
      success: true,
      message: `User status updated to ${status}`,
      user: googleSheets.sanitizeUser(user),
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update status', code: 'ADMIN_ERROR' });
  }
});

/**
 * PUT /api/admin/users/:id/plan
 * Change a user's subscription plan
 */
router.put('/users/:id/plan', async (req, res) => {
  try {
    const { plan } = req.body;

    if (!SUBSCRIPTION_PLANS[plan]) {
      return res.status(400).json({
        error: 'Invalid plan. Must be one of: free, basic, pro, enterprise',
        code: 'INVALID_PLAN',
      });
    }

    const planConfig = SUBSCRIPTION_PLANS[plan];
    const user = await googleSheets.updateUser(req.params.id, {
      plan,
      dailyLimit: planConfig.limits.dailyApiRequests,
      monthlyLimit: planConfig.limits.monthlyApiRequests,
      features: JSON.stringify(planConfig.features),
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found', code: 'NOT_FOUND' });
    }

    logger.info('Admin', `User plan changed: ${user.email} → ${plan}`, { adminEmail: req.user.email });

    res.json({
      success: true,
      message: `User plan changed to ${planConfig.displayName}`,
      user: googleSheets.sanitizeUser(user),
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update plan', code: 'ADMIN_ERROR' });
  }
});

/**
 * PUT /api/admin/users/:id/limits
 * Adjust custom usage limits for a user
 */
router.put('/users/:id/limits', async (req, res) => {
  try {
    const { dailyLimit, monthlyLimit } = req.body;
    const updates = {};

    if (dailyLimit !== undefined) updates.dailyLimit = parseInt(dailyLimit);
    if (monthlyLimit !== undefined) updates.monthlyLimit = parseInt(monthlyLimit);

    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ error: 'No limits specified', code: 'VALIDATION_ERROR' });
    }

    const user = await googleSheets.updateUser(req.params.id, updates);
    if (!user) {
      return res.status(404).json({ error: 'User not found', code: 'NOT_FOUND' });
    }

    logger.info('Admin', `User limits adjusted: ${user.email}`, { updates, adminEmail: req.user.email });

    res.json({
      success: true,
      message: 'Usage limits updated',
      user: googleSheets.sanitizeUser(user),
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update limits', code: 'ADMIN_ERROR' });
  }
});

/**
 * POST /api/admin/users/:id/reset-usage
 * Reset all usage counters for a user
 */
router.post('/users/:id/reset-usage', async (req, res) => {
  try {
    await googleSheets.resetUsage(req.params.id);

    logger.info('Admin', `Usage reset for user: ${req.params.id}`, { adminEmail: req.user.email });

    res.json({
      success: true,
      message: 'Usage counters reset successfully',
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to reset usage', code: 'ADMIN_ERROR' });
  }
});

/**
 * PUT /api/admin/users/:id/expiry
 * Set expiry date for a user
 */
router.put('/users/:id/expiry', async (req, res) => {
  try {
    const { expiryDate } = req.body;

    if (!expiryDate) {
      return res.status(400).json({ error: 'Expiry date required', code: 'VALIDATION_ERROR' });
    }

    const user = await googleSheets.updateUser(req.params.id, { expiryDate });
    if (!user) {
      return res.status(404).json({ error: 'User not found', code: 'NOT_FOUND' });
    }

    logger.info('Admin', `Expiry set for ${user.email}: ${expiryDate}`, { adminEmail: req.user.email });

    res.json({
      success: true,
      message: `Expiry date set to ${expiryDate}`,
      user: googleSheets.sanitizeUser(user),
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to set expiry', code: 'ADMIN_ERROR' });
  }
});

/**
 * POST /api/admin/users/:id/force-logout
 * Invalidate all sessions for a user
 */
router.post('/users/:id/force-logout', async (req, res) => {
  try {
    const user = await googleSheets.updateUser(req.params.id, { sessionHash: 'INVALIDATED' });
    if (!user) {
      return res.status(404).json({ error: 'User not found', code: 'NOT_FOUND' });
    }

    logger.info('Admin', `Force logout: ${user.email}`, { adminEmail: req.user.email });

    res.json({
      success: true,
      message: 'User sessions invalidated',
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to force logout', code: 'ADMIN_ERROR' });
  }
});

/**
 * GET /api/admin/stats
 * Get overall platform statistics
 */
router.get('/stats', async (req, res) => {
  try {
    const users = await googleSheets.getUsers();

    const stats = {
      totalUsers: users.length,
      activeUsers: users.filter((u) => u.status === USER_STATUS.ACTIVE).length,
      blockedUsers: users.filter((u) => u.status === USER_STATUS.BLOCKED).length,
      planDistribution: {
        free: users.filter((u) => u.plan === 'free').length,
        basic: users.filter((u) => u.plan === 'basic').length,
        pro: users.filter((u) => u.plan === 'pro').length,
        enterprise: users.filter((u) => u.plan === 'enterprise').length,
      },
      totalDailyUsage: users.reduce((sum, u) => sum + (parseInt(u.dailyUsage) || 0), 0),
      totalMonthlyUsage: users.reduce((sum, u) => sum + (parseInt(u.monthlyUsage) || 0), 0),
    };

    res.json({ success: true, stats });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats', code: 'ADMIN_ERROR' });
  }
});

/**
 * GET /api/admin/logins
 * Get login history for all users
 */
router.get('/logins', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 100;
    const history = await googleSheets.getLoginHistory(null, limit);
    res.json({ success: true, history });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch login history', code: 'ADMIN_ERROR' });
  }
});

module.exports = router;
