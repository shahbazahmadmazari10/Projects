/**
 * ai.js — AI Proxy Routes
 * Handles AI proposal generation through the secure backend proxy.
 * API key is never exposed to the client.
 */

const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { trackApiUsage } = require('../middleware/usageTracker');
const { aiLimiter } = require('../middleware/rateLimiter');
const { generateProposal, fallbackProposal } = require('../services/aiProxy');
const { SUBSCRIPTION_PLANS } = require('../config/constants');
const logger = require('../utils/logger');

/**
 * POST /api/ai/generate
 * Generate an AI proposal for a project
 * Protected by: auth → usage tracking → rate limiting
 */
router.post('/generate', requireAuth, trackApiUsage, aiLimiter, async (req, res) => {
  try {
    const { project, persona } = req.body;

    if (!project || !project.title) {
      return res.status(400).json({
        error: 'Project title is required',
        code: 'VALIDATION_ERROR',
      });
    }

    const user = req.user;
    const plan = SUBSCRIPTION_PLANS[user.plan] || SUBSCRIPTION_PLANS.free;

    // Check if custom persona is allowed on this plan
    const effectivePersona = plan.features.customPersona
      ? (persona || 'professional freelancer')
      : 'professional freelancer';

    // Generate proposal
    let proposal;
    try {
      proposal = await generateProposal(project, effectivePersona);
    } catch (err) {
      logger.warn('AI', `AI generation failed for ${user.email}, using fallback`, { error: err.message });
      proposal = fallbackProposal(project);

      return res.json({
        success: true,
        proposal,
        fallback: true,
        message: 'Used fallback proposal due to AI service issue',
      });
    }

    res.json({
      success: true,
      proposal,
      fallback: false,
    });
  } catch (err) {
    logger.error('AI', 'Proposal generation error', { error: err.message });
    res.status(500).json({
      error: 'Failed to generate proposal',
      code: 'AI_ERROR',
    });
  }
});

module.exports = router;
