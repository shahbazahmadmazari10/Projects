/**
 * auth.js — Authentication Routes
 * Handles registration, login, logout, and session management.
 */

const express = require('express');
const router = express.Router();
const { hashPassword, comparePassword } = require('../utils/hash');
const { signToken } = require('../utils/jwt');
const googleSheets = require('../services/googleSheets');
const { requireAuth } = require('../middleware/auth');
const { authLimiter } = require('../middleware/rateLimiter');
const logger = require('../utils/logger');
const { SUBSCRIPTION_PLANS, USER_ROLES } = require('../config/constants');

/**
 * POST /api/auth/register
 * Create a new user account
 */
router.post('/register', authLimiter, async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Validation
    if (!name || !email || !password) {
      return res.status(400).json({
        error: 'Name, email, and password are required',
        code: 'VALIDATION_ERROR',
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        error: 'Password must be at least 6 characters',
        code: 'WEAK_PASSWORD',
      });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        error: 'Invalid email address',
        code: 'INVALID_EMAIL',
      });
    }

    // Check if email already exists
    const existing = await googleSheets.getUserByEmail(email);
    if (existing) {
      return res.status(409).json({
        error: 'An account with this email already exists',
        code: 'EMAIL_EXISTS',
      });
    }

    // Hash password
    const passwordHash = await hashPassword(password);

    // Determine role (first user or matching admin email gets admin)
    const allUsers = await googleSheets.getUsers();
    const isAdmin = allUsers.length === 0 || email.toLowerCase() === (process.env.ADMIN_EMAIL || '').toLowerCase();

    // Create user
    const ip = req.ip || req.headers['x-forwarded-for'] || 'unknown';
    const device = req.headers['user-agent'] || 'unknown';

    const user = await googleSheets.createUser({
      name,
      email: email.toLowerCase(),
      passwordHash,
      plan: 'free',
      role: isAdmin ? USER_ROLES.ADMIN : USER_ROLES.USER,
      ip,
      device,
    });

    // Generate JWT
    const token = signToken({
      userId: user.userId,
      email: user.email,
      role: user.role,
    });

    // Log login
    await googleSheets.logLogin(user.userId, ip, device, true);

    const plan = SUBSCRIPTION_PLANS[user.plan];

    logger.info('Auth', `New user registered: ${user.email}`, { role: user.role });

    res.status(201).json({
      success: true,
      token,
      user: googleSheets.sanitizeUser(user),
      plan: {
        ...plan,
        features: plan.features,
      },
    });
  } catch (err) {
    logger.error('Auth', 'Registration error', { error: err.message });
    res.status(500).json({
      error: 'Registration failed. Please try again.',
      code: 'REGISTER_ERROR',
    });
  }
});

/**
 * POST /api/auth/login
 * Authenticate user and return JWT
 */
router.post('/login', authLimiter, async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        error: 'Email and password are required',
        code: 'VALIDATION_ERROR',
      });
    }

    const ip = req.ip || req.headers['x-forwarded-for'] || 'unknown';
    const device = req.headers['user-agent'] || 'unknown';

    // Find user
    const user = await googleSheets.getUserByEmail(email.toLowerCase());
    if (!user) {
      await googleSheets.logLogin('unknown', ip, device, false);
      return res.status(401).json({
        error: 'Invalid email or password',
        code: 'INVALID_CREDENTIALS',
      });
    }

    // Check password
    const isValid = await comparePassword(password, user.passwordHash);
    if (!isValid) {
      await googleSheets.logLogin(user.userId, ip, device, false);
      return res.status(401).json({
        error: 'Invalid email or password',
        code: 'INVALID_CREDENTIALS',
      });
    }

    // Check account status
    if (user.status === 'blocked') {
      await googleSheets.logLogin(user.userId, ip, device, false);
      return res.status(403).json({
        error: 'Your account has been blocked. Contact support.',
        code: 'ACCOUNT_BLOCKED',
      });
    }

    // Generate JWT
    const token = signToken({
      userId: user.userId,
      email: user.email,
      role: user.role,
    });

    // Update login info
    await googleSheets.updateUser(user.userId, {
      lastLogin: new Date().toISOString(),
      lastIp: ip,
      lastDevice: device,
    });

    // Log successful login
    await googleSheets.logLogin(user.userId, ip, device, true);

    const plan = SUBSCRIPTION_PLANS[user.plan] || SUBSCRIPTION_PLANS.free;

    logger.info('Auth', `User logged in: ${user.email}`);

    res.json({
      success: true,
      token,
      user: googleSheets.sanitizeUser(user),
      plan: {
        ...plan,
        features: plan.features,
      },
    });
  } catch (err) {
    logger.error('Auth', 'Login error', { error: err.message });
    res.status(500).json({
      error: 'Login failed. Please try again.',
      code: 'LOGIN_ERROR',
    });
  }
});

/**
 * GET /api/auth/me
 * Get current user profile (requires auth)
 */
router.get('/me', requireAuth, async (req, res) => {
  try {
    const user = req.user;
    const plan = SUBSCRIPTION_PLANS[user.plan] || SUBSCRIPTION_PLANS.free;
    const usageStats = await googleSheets.getUsageStats(user.userId);

    res.json({
      success: true,
      user: googleSheets.sanitizeUser(user),
      plan: {
        ...plan,
        features: plan.features,
      },
      usage: usageStats,
    });
  } catch (err) {
    logger.error('Auth', 'Profile fetch error', { error: err.message });
    res.status(500).json({ error: 'Failed to fetch profile', code: 'PROFILE_ERROR' });
  }
});

/**
 * POST /api/auth/logout
 * Invalidate user session
 */
router.post('/logout', requireAuth, async (req, res) => {
  try {
    await googleSheets.updateUser(req.userId, { sessionHash: '' });
    logger.info('Auth', `User logged out: ${req.user.email}`);
    res.json({ success: true, message: 'Logged out successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Logout failed', code: 'LOGOUT_ERROR' });
  }
});

module.exports = router;
