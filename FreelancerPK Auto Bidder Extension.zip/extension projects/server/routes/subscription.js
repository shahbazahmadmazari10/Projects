/**
 * subscription.js — Subscription Management Routes
 * Handles plan info, current status, and upgrade requests.
 */

const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { SUBSCRIPTION_PLANS } = require('../config/constants');
const googleSheets = require('../services/googleSheets');
const logger = require('../utils/logger');

/**
 * GET /api/subscription/plans
 * List all available subscription plans (public)
 */
router.get('/plans', (req, res) => {
  const plans = Object.values(SUBSCRIPTION_PLANS).map((plan) => ({
    id: plan.id,
    name: plan.displayName,
    color: plan.color,
    icon: plan.icon,
    price: plan.price,
    currency: plan.currency,
    billingCycle: plan.billingCycle,
    limits: plan.limits,
    features: plan.features,
    description: plan.description,
  }));

  res.json({ success: true, plans });
});

/**
 * GET /api/subscription/current
 * Get current user's subscription details
 */
router.get('/current', requireAuth, async (req, res) => {
  try {
    const user = req.user;
    const plan = SUBSCRIPTION_PLANS[user.plan] || SUBSCRIPTION_PLANS.free;
    const usage = await googleSheets.getUsageStats(user.userId);

    res.json({
      success: true,
      subscription: {
        plan: plan.id,
        planName: plan.displayName,
        color: plan.color,
        icon: plan.icon,
        price: plan.price,
        status: user.status,
        expiryDate: user.expiryDate,
        limits: plan.limits,
        features: plan.features,
        usage,
      },
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch subscription', code: 'SUB_ERROR' });
  }
});

/**
 * POST /api/subscription/upgrade
 * Request a plan upgrade (placeholder for payment integration)
 */
router.post('/upgrade', requireAuth, async (req, res) => {
  try {
    const { plan: requestedPlan } = req.body;

    if (!requestedPlan || !SUBSCRIPTION_PLANS[requestedPlan]) {
      return res.status(400).json({
        error: 'Invalid plan selected',
        code: 'INVALID_PLAN',
      });
    }

    const newPlan = SUBSCRIPTION_PLANS[requestedPlan];
    const currentPlan = SUBSCRIPTION_PLANS[req.user.plan] || SUBSCRIPTION_PLANS.free;

    if (newPlan.price <= currentPlan.price) {
      return res.status(400).json({
        error: 'Can only upgrade to a higher plan',
        code: 'INVALID_UPGRADE',
      });
    }

    // TODO: Integrate payment gateway (Stripe, JazzCash, EasyPaisa)
    // For now, just record the upgrade request

    logger.info('Subscription', `Upgrade requested by ${req.user.email}: ${req.user.plan} → ${requestedPlan}`);

    await googleSheets.logUsage(req.userId, 'upgrade_request', `${req.user.plan} → ${requestedPlan}`);

    res.json({
      success: true,
      message: 'Upgrade request received. Payment integration coming soon. Contact admin for manual upgrade.',
      requestedPlan: newPlan.displayName,
      price: newPlan.price,
      currency: newPlan.currency,
    });
  } catch (err) {
    logger.error('Subscription', 'Upgrade error', { error: err.message });
    res.status(500).json({ error: 'Upgrade request failed', code: 'UPGRADE_ERROR' });
  }
});

module.exports = router;
