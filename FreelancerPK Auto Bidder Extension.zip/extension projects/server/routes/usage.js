/**
 * usage.js — Usage Statistics Routes
 * Provides usage data for the user dashboard.
 */

const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const googleSheets = require('../services/googleSheets');
const { SUBSCRIPTION_PLANS } = require('../config/constants');

/**
 * GET /api/usage/stats
 * Get current usage statistics for the authenticated user
 */
router.get('/stats', requireAuth, async (req, res) => {
  try {
    const stats = await googleSheets.getUsageStats(req.userId);
    if (!stats) {
      return res.status(404).json({ error: 'Usage data not found', code: 'NOT_FOUND' });
    }

    const plan = SUBSCRIPTION_PLANS[req.user.plan] || SUBSCRIPTION_PLANS.free;

    res.json({
      success: true,
      usage: {
        ...stats,
        plan: req.user.plan,
        planName: plan.displayName,
        dailyRemaining: Math.max(0, stats.dailyLimit - stats.dailyUsage),
        monthlyRemaining: Math.max(0, stats.monthlyLimit - stats.monthlyUsage),
        dailyPercentage: stats.dailyLimit > 0 ? Math.round((stats.dailyUsage / stats.dailyLimit) * 100) : 0,
        monthlyPercentage: stats.monthlyLimit > 0 ? Math.round((stats.monthlyUsage / stats.monthlyLimit) * 100) : 0,
      },
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch usage stats', code: 'USAGE_ERROR' });
  }
});

/**
 * GET /api/usage/history
 * Get usage history logs
 */
router.get('/history', requireAuth, async (req, res) => {
  try {
    const loginHistory = await googleSheets.getLoginHistory(req.userId, 20);
    const plan = SUBSCRIPTION_PLANS[req.user.plan] || SUBSCRIPTION_PLANS.free;

    res.json({
      success: true,
      history: loginHistory,
      plan: plan.displayName,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch usage history', code: 'HISTORY_ERROR' });
  }
});

module.exports = router;
