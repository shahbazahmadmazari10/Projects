/**
 * server.js — Express Server Entry Point
 * FreelancerPK Auto Bidder SaaS Backend
 *
 * Provides secure API proxy, authentication, subscription management,
 * usage tracking, and admin controls.
 */

require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const logger = require('./utils/logger');
const googleSheets = require('./services/googleSheets');
const { generalLimiter } = require('./middleware/rateLimiter');

// Import routes
const authRoutes = require('./routes/auth');
const aiRoutes = require('./routes/ai');
const usageRoutes = require('./routes/usage');
const subscriptionRoutes = require('./routes/subscription');
const adminRoutes = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 3000;

// ===== Security Middleware =====
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' },
}));

// ===== CORS Configuration =====
app.use(cors({
  origin: [
    /^chrome-extension:\/\/.*/,
    /^http:\/\/localhost:\d+/,
    /^https:\/\/localhost:\d+/,
  ],
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  exposedHeaders: [
    'X-Daily-Usage', 'X-Daily-Limit', 'X-Daily-Remaining',
    'X-Monthly-Usage', 'X-Monthly-Limit', 'X-Monthly-Remaining',
    'X-Usage-Warning',
  ],
  credentials: true,
}));

// ===== Body Parser =====
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

// ===== Request Logging =====
if (process.env.NODE_ENV !== 'test') {
  app.use(morgan('short'));
}

// ===== Rate Limiting =====
app.use('/api/', generalLimiter);

// ===== Health Check =====
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'FreelancerPK Auto Bidder API',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    demoMode: googleSheets.isDemoMode(),
  });
});

// ===== API Routes =====
app.use('/api/auth', authRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/usage', usageRoutes);
app.use('/api/subscription', subscriptionRoutes);
app.use('/api/admin', adminRoutes);

// ===== 404 Handler =====
app.use((req, res) => {
  res.status(404).json({
    error: 'Endpoint not found',
    code: 'NOT_FOUND',
    path: req.originalUrl,
  });
});

// ===== Global Error Handler =====
app.use((err, req, res, _next) => {
  logger.error('Server', 'Unhandled error', {
    error: err.message,
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined,
    path: req.originalUrl,
    method: req.method,
  });

  res.status(err.status || 500).json({
    error: process.env.NODE_ENV === 'production'
      ? 'Internal server error'
      : err.message,
    code: 'SERVER_ERROR',
  });
});

// ===== Start Server =====
async function start() {
  // Initialize Google Sheets connection
  const sheetsConnected = await googleSheets.initialize();

  if (!sheetsConnected) {
    logger.warn('Server', '⚠ Running in DEMO MODE — Google Sheets not connected');
    logger.warn('Server', 'Data will be stored in memory and lost on restart');
    logger.warn('Server', 'Set GOOGLE_SHEET_ID and credentials to enable persistence');
  }

  app.listen(PORT, () => {
    logger.info('Server', `🚀 Server running on http://localhost:${PORT}`);
    logger.info('Server', `Environment: ${process.env.NODE_ENV || 'development'}`);
    logger.info('Server', `API Key configured: ${process.env.XAI_API_KEY ? 'Yes' : 'No'}`);
    logger.info('Server', `Demo mode: ${!sheetsConnected}`);
  });
}

start().catch((err) => {
  logger.error('Server', 'Failed to start server', { error: err.message });
  process.exit(1);
});

module.exports = app;
