/**
 * aiProxy.js — AI API Proxy Service
 * Handles all communication with the xAI API using the server-side API key.
 * The API key NEVER leaves the server.
 */

const logger = require('../utils/logger');
const { AI_CONFIG } = require('../config/constants');

/**
 * Generate a proposal using the xAI API
 * @param {Object} project — { title, description, skills }
 * @param {string} persona — AI persona description
 * @returns {Promise<string>} generated proposal text
 */
async function generateProposal(project, persona = 'professional freelancer') {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) {
    throw new Error('AI API key not configured on server');
  }

  const systemPrompt = buildSystemPrompt(persona);
  const userPrompt = buildUserPrompt(project);

  try {
    const response = await fetch(AI_CONFIG.API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: AI_CONFIG.MODEL,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        temperature: AI_CONFIG.TEMPERATURE,
        max_tokens: AI_CONFIG.MAX_TOKENS,
        stream: false,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      const errorMsg = errorData.error?.message || response.statusText;

      if (response.status === 429) {
        logger.warn('AIProxy', 'Rate limited by xAI API');
        throw new Error('AI service is temporarily rate limited. Please try again shortly.');
      }

      logger.error('AIProxy', `xAI API error: ${response.status}`, { error: errorMsg });
      throw new Error(`AI service error: ${errorMsg}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || '';
    const cleaned = cleanResponse(content);

    logger.info('AIProxy', 'Proposal generated successfully', {
      titlePreview: project.title?.substring(0, 40),
      responseLength: cleaned.length,
    });

    return cleaned;
  } catch (err) {
    if (err.message.includes('AI service')) throw err;
    logger.error('AIProxy', 'Failed to generate proposal', { error: err.message });
    throw new Error('Failed to connect to AI service');
  }
}

function buildSystemPrompt(persona) {
  return `You are a ${persona} on Freelancer.pk.
Your task is to write a short, professional freelancing proposal.

Rules:
- Keep it under 150 words
- Professional yet friendly tone
- Mention relevant experience briefly
- Highlight fast delivery
- Show understanding of the project requirements
- Do NOT use markdown formatting
- Do NOT include greetings like "Dear Sir/Madam"
- Start with "Hi," or "Hello,"
- End with a brief call to action`;
}

function buildUserPrompt(project) {
  let prompt = `Write a proposal for this project:\n\n`;
  prompt += `Project Title: ${project.title}\n\n`;
  if (project.description) {
    prompt += `Project Description:\n${project.description.substring(0, 1000)}\n\n`;
  }
  if (project.skills && project.skills.length > 0) {
    const skillsList = Array.isArray(project.skills) ? project.skills.join(', ') : project.skills;
    prompt += `Required Skills: ${skillsList}\n`;
  }
  return prompt;
}

function cleanResponse(response) {
  if (!response) return '';
  let cleaned = response
    .replace(/```[\s\S]*?```/g, '')
    .replace(/\*\*/g, '')
    .replace(/\*/g, '')
    .replace(/#{1,6}\s/g, '')
    .replace(/---/g, '')
    .trim();
  cleaned = cleaned.replace(/^(Subject|Proposal|Title|Re):.*\n/im, '').trim();
  return cleaned;
}

/**
 * Fallback proposal when AI is unavailable
 */
function fallbackProposal(project) {
  return `Hello,

I am interested in your project "${project.title}". I have relevant experience and can deliver high-quality work within your timeline.

I have carefully reviewed your requirements and I am confident I can meet your expectations. I focus on clear communication, timely delivery, and professional quality.

Looking forward to working with you.

Best regards`;
}

module.exports = { generateProposal, fallbackProposal };
