/**
 * googleSheets.js — Google Sheets Database Service
 * Full CRUD operations for Users, UsageLogs, and LoginHistory sheets.
 */

const { google } = require('googleapis');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/logger');
const { SHEET_COLUMNS, SHEET_NAMES, USER_STATUS, USER_ROLES, SUBSCRIPTION_PLANS } = require('../config/constants');

let sheetsApi = null;
let spreadsheetId = null;

/**
 * Initialize Google Sheets API connection
 */
async function initialize() {
  try {
    const credentialsPath = path.resolve(process.env.GOOGLE_CREDENTIALS_PATH || './config/google-credentials.json');
    spreadsheetId = process.env.GOOGLE_SHEET_ID;

    if (!spreadsheetId) {
      logger.warn('GoogleSheets', 'GOOGLE_SHEET_ID not set — running in demo mode');
      return false;
    }

    const auth = new google.auth.GoogleAuth({
      keyFile: credentialsPath,
      scopes: ['https://www.googleapis.com/auth/spreadsheets'],
    });

    const authClient = await auth.getClient();
    sheetsApi = google.sheets({ version: 'v4', auth: authClient });

    // Verify connection by reading sheet metadata
    await sheetsApi.spreadsheets.get({ spreadsheetId });
    logger.info('GoogleSheets', 'Connected to Google Sheets successfully');

    // Ensure sheet tabs exist
    await ensureSheetTabs();
    return true;
  } catch (err) {
    logger.error('GoogleSheets', 'Failed to initialize Google Sheets', { error: err.message });
    return false;
  }
}

/**
 * Ensure required sheet tabs exist with headers
 */
async function ensureSheetTabs() {
  try {
    const response = await sheetsApi.spreadsheets.get({ spreadsheetId });
    const existingSheets = response.data.sheets.map((s) => s.properties.title);

    const requiredSheets = [
      {
        name: SHEET_NAMES.USERS,
        headers: ['UserID', 'Name', 'Email', 'PasswordHash', 'Plan', 'Status', 'ExpiryDate',
          'DailyUsage', 'MonthlyUsage', 'DailyLimit', 'MonthlyLimit', 'AutomationRuns',
          'LastLogin', 'LastIP', 'LastDevice', 'SessionHash', 'Role', 'CreatedAt', 'Features', 'LastReset'],
      },
      {
        name: SHEET_NAMES.USAGE_LOGS,
        headers: ['UserID', 'Timestamp', 'Type', 'Details'],
      },
      {
        name: SHEET_NAMES.LOGIN_HISTORY,
        headers: ['UserID', 'Timestamp', 'IP', 'Device', 'Success'],
      },
    ];

    for (const sheet of requiredSheets) {
      if (!existingSheets.includes(sheet.name)) {
        // Add new sheet tab
        await sheetsApi.spreadsheets.batchUpdate({
          spreadsheetId,
          requestBody: {
            requests: [{ addSheet: { properties: { title: sheet.name } } }],
          },
        });

        // Add headers
        await sheetsApi.spreadsheets.values.update({
          spreadsheetId,
          range: `${sheet.name}!A1`,
          valueInputOption: 'RAW',
          requestBody: { values: [sheet.headers] },
        });

        logger.info('GoogleSheets', `Created sheet tab: ${sheet.name}`);
      }
    }
  } catch (err) {
    logger.error('GoogleSheets', 'Error ensuring sheet tabs', { error: err.message });
  }
}

// ===== In-Memory Fallback (Demo Mode) =====

const demoStore = {
  users: [],
  usageLogs: [],
  loginHistory: [],
};

function isDemoMode() {
  return !sheetsApi || !spreadsheetId;
}

// ===== USER OPERATIONS =====

/**
 * Get all users from the Users sheet
 * @returns {Promise<Array<Object>>}
 */
async function getUsers() {
  if (isDemoMode()) return demoStore.users;

  try {
    const response = await sheetsApi.spreadsheets.values.get({
      spreadsheetId,
      range: `${SHEET_NAMES.USERS}!A2:T`,
    });

    const rows = response.data.values || [];
    return rows.map(rowToUser);
  } catch (err) {
    logger.error('GoogleSheets', 'Error fetching users', { error: err.message });
    return [];
  }
}

/**
 * Get a user by their ID
 * @param {string} userId
 * @returns {Promise<Object|null>}
 */
async function getUserById(userId) {
  if (isDemoMode()) {
    return demoStore.users.find((u) => u.userId === userId) || null;
  }

  const users = await getUsers();
  return users.find((u) => u.userId === userId) || null;
}

/**
 * Get a user by email
 * @param {string} email
 * @returns {Promise<Object|null>}
 */
async function getUserByEmail(email) {
  if (isDemoMode()) {
    return demoStore.users.find((u) => u.email.toLowerCase() === email.toLowerCase()) || null;
  }

  const users = await getUsers();
  return users.find((u) => u.email.toLowerCase() === email.toLowerCase()) || null;
}

/**
 * Create a new user
 * @param {Object} data — { name, email, passwordHash, plan, role }
 * @returns {Promise<Object>} created user
 */
async function createUser(data) {
  const plan = SUBSCRIPTION_PLANS[data.plan || 'free'];
  const now = new Date().toISOString();
  const expiry = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(); // 30 days

  const user = {
    userId: uuidv4(),
    name: data.name,
    email: data.email,
    passwordHash: data.passwordHash,
    plan: data.plan || 'free',
    status: USER_STATUS.ACTIVE,
    expiryDate: expiry,
    dailyUsage: 0,
    monthlyUsage: 0,
    dailyLimit: plan.limits.dailyApiRequests,
    monthlyLimit: plan.limits.monthlyApiRequests,
    automationRuns: 0,
    lastLogin: now,
    lastIp: data.ip || '',
    lastDevice: data.device || '',
    sessionHash: '',
    role: data.role || USER_ROLES.USER,
    createdAt: now,
    features: JSON.stringify(plan.features),
    lastReset: now,
  };

  if (isDemoMode()) {
    demoStore.users.push(user);
    return user;
  }

  try {
    const row = userToRow(user);
    await sheetsApi.spreadsheets.values.append({
      spreadsheetId,
      range: `${SHEET_NAMES.USERS}!A:T`,
      valueInputOption: 'RAW',
      requestBody: { values: [row] },
    });

    logger.info('GoogleSheets', `User created: ${user.email}`, { userId: user.userId });
    return user;
  } catch (err) {
    logger.error('GoogleSheets', 'Error creating user', { error: err.message });
    throw new Error('Failed to create user');
  }
}

/**
 * Update user fields by userId
 * @param {string} userId
 * @param {Object} fields — key-value pairs to update
 * @returns {Promise<Object|null>}
 */
async function updateUser(userId, fields) {
  if (isDemoMode()) {
    const idx = demoStore.users.findIndex((u) => u.userId === userId);
    if (idx === -1) return null;
    Object.assign(demoStore.users[idx], fields);
    return demoStore.users[idx];
  }

  try {
    // Find the user's row number
    const response = await sheetsApi.spreadsheets.values.get({
      spreadsheetId,
      range: `${SHEET_NAMES.USERS}!A:A`,
    });

    const rows = response.data.values || [];
    let rowIndex = -1;
    for (let i = 1; i < rows.length; i++) {
      if (rows[i][0] === userId) {
        rowIndex = i + 1; // 1-indexed, +1 for header
        break;
      }
    }

    if (rowIndex === -1) return null;

    // Get current row data
    const currentRow = await sheetsApi.spreadsheets.values.get({
      spreadsheetId,
      range: `${SHEET_NAMES.USERS}!A${rowIndex}:T${rowIndex}`,
    });

    const currentData = currentRow.data.values?.[0] || [];
    const user = rowToUser(currentData);

    // Apply updates
    Object.assign(user, fields);

    // Write back
    const updatedRow = userToRow(user);
    await sheetsApi.spreadsheets.values.update({
      spreadsheetId,
      range: `${SHEET_NAMES.USERS}!A${rowIndex}:T${rowIndex}`,
      valueInputOption: 'RAW',
      requestBody: { values: [updatedRow] },
    });

    logger.info('GoogleSheets', `User updated: ${userId}`, { fields: Object.keys(fields) });
    return user;
  } catch (err) {
    logger.error('GoogleSheets', 'Error updating user', { error: err.message, userId });
    throw new Error('Failed to update user');
  }
}

// ===== USAGE OPERATIONS =====

/**
 * Log a usage event
 * @param {string} userId
 * @param {string} type — 'api_request', 'automation_run', etc.
 * @param {string} details
 */
async function logUsage(userId, type, details = '') {
  const entry = {
    userId,
    timestamp: new Date().toISOString(),
    type,
    details,
  };

  if (isDemoMode()) {
    demoStore.usageLogs.push(entry);
    return;
  }

  try {
    await sheetsApi.spreadsheets.values.append({
      spreadsheetId,
      range: `${SHEET_NAMES.USAGE_LOGS}!A:D`,
      valueInputOption: 'RAW',
      requestBody: {
        values: [[entry.userId, entry.timestamp, entry.type, entry.details]],
      },
    });
  } catch (err) {
    logger.error('GoogleSheets', 'Error logging usage', { error: err.message });
  }
}

/**
 * Get usage stats for a user
 * @param {string} userId
 * @returns {Promise<Object>}
 */
async function getUsageStats(userId) {
  const user = await getUserById(userId);
  if (!user) return null;

  const plan = SUBSCRIPTION_PLANS[user.plan] || SUBSCRIPTION_PLANS.free;

  return {
    dailyUsage: parseInt(user.dailyUsage) || 0,
    monthlyUsage: parseInt(user.monthlyUsage) || 0,
    automationRuns: parseInt(user.automationRuns) || 0,
    dailyLimit: parseInt(user.dailyLimit) || plan.limits.dailyApiRequests,
    monthlyLimit: parseInt(user.monthlyLimit) || plan.limits.monthlyApiRequests,
    dailyAutomationLimit: plan.limits.dailyAutomationRuns,
    maxBidsPerRun: plan.limits.maxBidsPerRun,
    lastReset: user.lastReset,
  };
}

/**
 * Increment usage counters for a user
 * @param {string} userId
 * @param {string} type — 'api' or 'automation'
 */
async function incrementUsage(userId, type = 'api') {
  const user = await getUserById(userId);
  if (!user) return;

  const updates = {};
  const now = new Date();
  const lastReset = new Date(user.lastReset || 0);

  // Check if daily reset needed (new day)
  if (now.toDateString() !== lastReset.toDateString()) {
    updates.dailyUsage = 0;
    updates.automationRuns = 0;
    updates.lastReset = now.toISOString();
  }

  // Check if monthly reset needed (new month)
  if (now.getMonth() !== lastReset.getMonth() || now.getFullYear() !== lastReset.getFullYear()) {
    updates.monthlyUsage = 0;
  }

  if (type === 'api') {
    updates.dailyUsage = (parseInt(updates.dailyUsage ?? user.dailyUsage) || 0) + 1;
    updates.monthlyUsage = (parseInt(updates.monthlyUsage ?? user.monthlyUsage) || 0) + 1;
  } else if (type === 'automation') {
    updates.automationRuns = (parseInt(updates.automationRuns ?? user.automationRuns) || 0) + 1;
  }

  await updateUser(userId, updates);
  await logUsage(userId, type, `${type} request at ${now.toISOString()}`);
}

/**
 * Reset usage counters for a user
 * @param {string} userId
 */
async function resetUsage(userId) {
  await updateUser(userId, {
    dailyUsage: 0,
    monthlyUsage: 0,
    automationRuns: 0,
    lastReset: new Date().toISOString(),
  });
}

// ===== LOGIN HISTORY =====

/**
 * Log a login attempt
 * @param {string} userId
 * @param {string} ip
 * @param {string} device
 * @param {boolean} success
 */
async function logLogin(userId, ip, device, success) {
  const entry = {
    userId,
    timestamp: new Date().toISOString(),
    ip: ip || 'unknown',
    device: device || 'unknown',
    success: success ? 'true' : 'false',
  };

  if (isDemoMode()) {
    demoStore.loginHistory.push(entry);
    return;
  }

  try {
    await sheetsApi.spreadsheets.values.append({
      spreadsheetId,
      range: `${SHEET_NAMES.LOGIN_HISTORY}!A:E`,
      valueInputOption: 'RAW',
      requestBody: {
        values: [[entry.userId, entry.timestamp, entry.ip, entry.device, entry.success]],
      },
    });
  } catch (err) {
    logger.error('GoogleSheets', 'Error logging login', { error: err.message });
  }
}

/**
 * Get login history for a user (or all users for admin)
 * @param {string|null} userId — null for all
 * @param {number} limit
 * @returns {Promise<Array>}
 */
async function getLoginHistory(userId = null, limit = 50) {
  if (isDemoMode()) {
    let history = demoStore.loginHistory;
    if (userId) history = history.filter((h) => h.userId === userId);
    return history.slice(-limit).reverse();
  }

  try {
    const response = await sheetsApi.spreadsheets.values.get({
      spreadsheetId,
      range: `${SHEET_NAMES.LOGIN_HISTORY}!A2:E`,
    });

    let rows = (response.data.values || []).map((row) => ({
      userId: row[0] || '',
      timestamp: row[1] || '',
      ip: row[2] || '',
      device: row[3] || '',
      success: row[4] === 'true',
    }));

    if (userId) rows = rows.filter((r) => r.userId === userId);
    return rows.slice(-limit).reverse();
  } catch (err) {
    logger.error('GoogleSheets', 'Error fetching login history', { error: err.message });
    return [];
  }
}

// ===== HELPER FUNCTIONS =====

function rowToUser(row) {
  return {
    userId: row[0] || '',
    name: row[1] || '',
    email: row[2] || '',
    passwordHash: row[3] || '',
    plan: row[4] || 'free',
    status: row[5] || USER_STATUS.ACTIVE,
    expiryDate: row[6] || '',
    dailyUsage: parseInt(row[7]) || 0,
    monthlyUsage: parseInt(row[8]) || 0,
    dailyLimit: parseInt(row[9]) || 10,
    monthlyLimit: parseInt(row[10]) || 100,
    automationRuns: parseInt(row[11]) || 0,
    lastLogin: row[12] || '',
    lastIp: row[13] || '',
    lastDevice: row[14] || '',
    sessionHash: row[15] || '',
    role: row[16] || USER_ROLES.USER,
    createdAt: row[17] || '',
    features: row[18] || '{}',
    lastReset: row[19] || '',
  };
}

function userToRow(user) {
  return [
    user.userId,
    user.name,
    user.email,
    user.passwordHash,
    user.plan,
    user.status,
    user.expiryDate,
    String(user.dailyUsage || 0),
    String(user.monthlyUsage || 0),
    String(user.dailyLimit || 10),
    String(user.monthlyLimit || 100),
    String(user.automationRuns || 0),
    user.lastLogin,
    user.lastIp,
    user.lastDevice,
    user.sessionHash,
    user.role,
    user.createdAt,
    typeof user.features === 'string' ? user.features : JSON.stringify(user.features),
    user.lastReset || '',
  ];
}

/**
 * Get a safe user profile (without sensitive fields)
 * @param {Object} user
 * @returns {Object}
 */
function sanitizeUser(user) {
  const { passwordHash, sessionHash, ...safe } = user;
  try {
    safe.features = typeof safe.features === 'string' ? JSON.parse(safe.features) : safe.features;
  } catch {
    safe.features = {};
  }
  return safe;
}

module.exports = {
  initialize,
  getUsers,
  getUserById,
  getUserByEmail,
  createUser,
  updateUser,
  logUsage,
  getUsageStats,
  incrementUsage,
  resetUsage,
  logLogin,
  getLoginHistory,
  sanitizeUser,
  isDemoMode,
};
