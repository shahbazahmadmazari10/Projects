/**
 * jwt.js — JSON Web Token Utility
 * Handles signing, verifying, and decoding JWT tokens.
 */

const jwt = require('jsonwebtoken');

const SECRET = process.env.JWT_SECRET || 'fallback-secret-do-not-use-in-production';
const EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';

/**
 * Sign a new JWT token
 * @param {Object} payload — data to encode (userId, email, role)
 * @returns {string} signed JWT
 */
function signToken(payload) {
  return jwt.sign(payload, SECRET, { expiresIn: EXPIRES_IN });
}

/**
 * Verify and decode a JWT token
 * @param {string} token
 * @returns {Object} decoded payload
 * @throws {Error} if token is invalid or expired
 */
function verifyToken(token) {
  return jwt.verify(token, SECRET);
}

/**
 * Decode a token without verification (for debugging)
 * @param {string} token
 * @returns {Object|null}
 */
function decodeToken(token) {
  return jwt.decode(token);
}

module.exports = { signToken, verifyToken, decodeToken };
