@echo off
echo ===================================================
echo   Starting FreelancerPK Auto Bidder Backend Server
echo ===================================================
echo.

:: Check if Node.js is installed
node -v >nul 2>&1
if %errorlevel% neq 0 (
  echo ERROR: Node.js is not installed or not in PATH.
  echo The backend server requires Node.js to run.
  echo Please download and install it from: https://nodejs.org/
  echo.
  pause
  exit /b 1
)

:: Navigate to the server directory
cd server

:: Check if dependencies are installed
if not exist node_modules (
  echo [1/2] Installing dependencies...
  call npm install
  if %errorlevel% neq 0 (
    echo ERROR: Failed to install dependencies.
    pause
    exit /b 1
  )
) else (
  echo [1/2] Dependencies already installed.
)

:: Start the server
echo [2/2] Starting server on http://localhost:3000...
echo.
call npm start

pause
