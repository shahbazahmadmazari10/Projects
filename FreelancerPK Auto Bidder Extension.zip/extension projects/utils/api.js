/**
 * api.js — Backend API Client (Google Apps Script Version)
 * Centralized HTTP client for all backend communication.
 */

// ⚠️ REPLACE THIS WITH YOUR DEPLOYED GOOGLE APPS SCRIPT WEB APP URL
const API_BASE_URL = 'https://script.google.com/macros/s/AKfycbw3zV3den9aVEouKKxYYOF1LGOrf96-BGjWkYT80UMoWiVxlss4xuMrKCrUkjftCzQa/exec';

const ApiClient = {
  async getToken() {
    return new Promise((resolve) => {
      chrome.storage.local.get('authToken', (result) => {
        resolve(result.authToken || null);
      });
    });
  },

  async setToken(token) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ authToken: token }, resolve);
    });
  },

  async clearToken() {
    return new Promise((resolve) => {
      chrome.storage.local.remove(['authToken', 'userProfile', 'subscriptionInfo'], resolve);
    });
  },

  /**
   * Make a request to the Google Apps Script Web App
   * @param {string} action - The action parameter for doPost routing
   * @param {Object} payload - Data to send
   */
  async request(action, payload = {}) {
    const token = await this.getToken();
    
    // Add action and token to the payload
    const bodyData = {
      action: action,
      ...payload
    };
    if (token) {
      bodyData.token = token;
    }

    try {
      const response = await fetch(API_BASE_URL, {
        method: 'POST',
        headers: {
          // 'Content-Type': 'text/plain;charset=utf-8', 
          // Apps script sometimes struggles with application/json CORS, but we'll try standard json first
          // Actually, standard fetch without custom headers often works best for Apps Script
        },
        body: JSON.stringify(bodyData)
      });

      const data = await response.json().catch(() => ({}));

      if (response.status === 401 || data.code === 'INVALID_TOKEN') {
        await this.clearToken();
        return { success: false, error: data.error || 'Session expired', code: 'AUTH_REQUIRED' };
      }

      if (!data.success && !data.status) {
        // Handle generic failure
        return {
          success: false,
          error: data.error || 'Request failed',
          code: data.code || 'REQUEST_ERROR',
          ...data
        };
      }

      return data;
    } catch (err) {
      return {
        success: false,
        error: 'Cannot connect to server. Check your internet connection or Web App URL.',
        code: 'CONNECTION_ERROR'
      };
    }
  },

  // ===== Auth Endpoints =====

  async register(name, email, password) {
    const result = await this.request('register', { name, email, password });
    if (result.success && result.token) {
      await this.setToken(result.token);
      await this.cacheProfile(result.user, result.plan);
    }
    return result;
  },

  async login(email, password) {
    const result = await this.request('login', { email, password });
    if (result.success && result.token) {
      await this.setToken(result.token);
      await this.cacheProfile(result.user, result.plan);
    }
    return result;
  },

  async logout() {
    await this.request('logout');
    await this.clearToken();
  },

  async getProfile() {
    return this.request('me');
  },

  // ===== AI Endpoints =====

  async generateProposal(project, persona) {
    return this.request('generateAI', { project, persona });
  },

  // ===== Usage Endpoints =====

  async getUsageStats() {
    return this.request('getUsageStats');
  },

  async getUsageHistory() {
    return this.request('getUsageHistory');
  },

  async recordBidProcessed(projectId, title, success) {
    return this.request('recordBidProcessed', { projectId, title, success });
  },

  // ===== Subscription Endpoints =====

  async getPlans() {
    return this.request('getPlans');
  },

  async getCurrentSubscription() {
    return this.request('getCurrentSubscription');
  },

  async requestUpgrade(plan) {
    return this.request('requestUpgrade', { plan });
  },

  // ===== Health Check =====

  async healthCheck() {
    return this.request('health');
  },

  // ===== Cache Helpers =====

  async cacheProfile(user, plan) {
    return new Promise((resolve) => {
      chrome.storage.local.set({
        userProfile: user,
        subscriptionInfo: plan,
      }, resolve);
    });
  },

  async getCachedProfile() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['userProfile', 'subscriptionInfo'], (result) => {
        resolve({
          user: result.userProfile || null,
          plan: result.subscriptionInfo || null,
        });
      });
    });
  },
};

if (typeof globalThis !== 'undefined') {
  globalThis.ApiClient = ApiClient;
}
