/**
 * auth.js — Auth State Management for Chrome Extension
 * Simplified for Google Apps Script token-based auth (no JWT).
 */

const AuthManager = {
  /**
   * Check if user is logged in (has a session token)
   * @returns {Promise<boolean>}
   */
  async isLoggedIn() {
    const token = await this.getToken();
    return !!token;
  },

  /**
   * Get the stored session token
   * @returns {Promise<string|null>}
   */
  async getToken() {
    return new Promise((resolve) => {
      chrome.storage.local.get('authToken', (result) => {
        resolve(result.authToken || null);
      });
    });
  },

  /**
   * Get cached user profile
   * @returns {Promise<Object|null>}
   */
  async getProfile() {
    return new Promise((resolve) => {
      chrome.storage.local.get('userProfile', (result) => {
        resolve(result.userProfile || null);
      });
    });
  },

  /**
   * Get cached subscription info
   * @returns {Promise<Object|null>}
   */
  async getSubscription() {
    return new Promise((resolve) => {
      chrome.storage.local.get('subscriptionInfo', (result) => {
        resolve(result.subscriptionInfo || null);
      });
    });
  },

  /**
   * Clear all auth data (logout)
   */
  async logout() {
    return new Promise((resolve) => {
      chrome.storage.local.remove(
        ['authToken', 'userProfile', 'subscriptionInfo'],
        resolve
      );
    });
  },
};

if (typeof globalThis !== 'undefined') {
  globalThis.AuthManager = AuthManager;
}
