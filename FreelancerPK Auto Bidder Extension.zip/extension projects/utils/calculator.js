/**
 * calculator.js — Budget & Delivery Day Calculator
 */
var Calculator = Calculator || {
  /**
   * Reduce budget by a percentage
   * @param {number} originalBudget
   * @param {number} reductionPercent
   * @returns {number}
   */
  reduceBudget(originalBudget, reductionPercent) {
    const reduced = originalBudget - (originalBudget * reductionPercent / 100);
    return Math.floor(reduced);
  },

  /**
   * Reduce delivery days by a percentage
   * @param {number} originalDays
   * @param {number} reductionPercent
   * @returns {number}
   */
  reduceDeliveryDays(originalDays, reductionPercent) {
    const reduced = originalDays * (1 - reductionPercent / 100);
    return Math.max(1, Math.ceil(reduced));
  },

  /**
   * Parse a budget string like "$250 - $750 USD" or "$500 USD"
   * @param {string} budgetString
   * @returns {{min: number, max: number, currency: string}}
   */
  parseBudgetRange(budgetString) {
    if (!budgetString) return { min: 0, max: 0, currency: 'USD' };

    const cleaned = budgetString.replace(/,/g, '');
    // Extract currency
    const currencyMatch = cleaned.match(/[A-Z]{3}/);
    const currency = currencyMatch ? currencyMatch[0] : 'USD';

    // Extract numbers
    const numbers = cleaned.match(/[\d.]+/g);
    if (!numbers || numbers.length === 0) return { min: 0, max: 0, currency };

    const values = numbers.map(Number);
    if (values.length === 1) {
      return { min: values[0], max: values[0], currency };
    }
    return { min: values[0], max: values[1], currency };
  },

  /**
   * Get the bid amount from a budget range (uses the minimum of the range)
   * @param {string} budgetString
   * @param {number} reductionPercent
   * @returns {number}
   */
  calculateBidAmount(budgetString, reductionPercent) {
    const { min, max } = Calculator.parseBudgetRange(budgetString);
    // Use the average of the range as the base
    const base = min === max ? min : Math.floor((min + max) / 2);
    return Calculator.reduceBudget(base, reductionPercent);
  },

  /**
   * Parse a delivery string like "10 days" or "Within 7 days"
   * @param {string} daysString
   * @returns {number}
   */
  parseDays(daysString) {
    if (!daysString) return 7; // default
    const match = daysString.match(/(\d+)/);
    return match ? parseInt(match[1], 10) : 7;
  }
};

if (typeof globalThis !== 'undefined') {
  globalThis.Calculator = Calculator;
}
