/**
 * proposal.js — Prompt Builder & Response Cleaner
 */
const ProposalUtil = {
  /**
   * Build the system prompt for Groq
   * @param {string} persona — e.g. "professional 3D designer"
   * @returns {string}
   */
  buildSystemPrompt(persona) {
    return `You are a ${persona} on Freelancer.pk.
Your task is to write a short, professional freelancing proposal.

Rules:
- Keep it under 150 words
- Professional yet friendly tone
- Mention relevant experience briefly
- Highlight fast delivery
- Show understanding of the project requirements
- Do NOT use markdown formatting
- Do NOT include greetings like "Dear Sir/Madam"
- Start with "Hi," or "Hello,"
- End with a brief call to action`;
  },

  /**
   * Build the user prompt with project details
   * @param {Object} project — {title, description, skills}
   * @returns {string}
   */
  buildUserPrompt(project) {
    let prompt = `Write a proposal for this project:\n\n`;
    prompt += `Project Title: ${project.title}\n\n`;
    if (project.description) {
      prompt += `Project Description:\n${project.description.substring(0, 1000)}\n\n`;
    }
    if (project.skills && project.skills.length > 0) {
      prompt += `Required Skills: ${project.skills.join(', ')}\n`;
    }
    return prompt;
  },

  /**
   * Clean AI response — strip markdown artifacts and trim
   * @param {string} response
   * @returns {string}
   */
  cleanResponse(response) {
    if (!response) return '';
    let cleaned = response
      .replace(/```[\s\S]*?```/g, '')
      .replace(/\*\*/g, '')
      .replace(/\*/g, '')
      .replace(/#{1,6}\s/g, '')
      .replace(/---/g, '')
      .trim();

    // Remove any "Subject:" or "Proposal:" headers the AI might add
    cleaned = cleaned.replace(/^(Subject|Proposal|Title|Re):.*\n/im, '').trim();
    return cleaned;
  },

  /**
   * Fallback proposal template if API fails
   * @param {Object} project
   * @returns {string}
   */
  fallbackProposal(project) {
    return `Hello,

I am interested in your project "${project.title}". I have relevant experience in this area and can deliver high-quality work within your timeline.

I have carefully reviewed your requirements and I am confident I can meet your expectations. I focus on clear communication, timely delivery, and professional quality.

I would love to discuss the project details further. Please feel free to reach out.

Looking forward to working with you.

Best regards`;
  }
};

if (typeof globalThis !== 'undefined') {
  globalThis.ProposalUtil = ProposalUtil;
}
