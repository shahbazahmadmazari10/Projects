/**
 * scraper.js — DOM Scraping Utilities for freelancer.pk
 * Handles waiting for elements, scraping project cards, and project detail extraction.
 */
var Scraper = Scraper || {
  /**
   * Wait for an element to appear in the DOM
   * @param {string} selector — CSS selector
   * @param {number} timeout — Max wait time in ms
   * @returns {Promise<Element>}
   */
  waitForElement(selector, timeout = 10000) {
    return new Promise((resolve, reject) => {
      const el = document.querySelector(selector);
      if (el) return resolve(el);

      const observer = new MutationObserver(() => {
        const el = document.querySelector(selector);
        if (el) {
          observer.disconnect();
          resolve(el);
        }
      });

      observer.observe(document.body, { childList: true, subtree: true });

      setTimeout(() => {
        observer.disconnect();
        reject(new Error(`Element "${selector}" not found within ${timeout}ms`));
      }, timeout);
    });
  },

  /**
   * Wait for multiple elements
   * @param {string} selector
   * @param {number} minCount
   * @param {number} timeout
   * @returns {Promise<NodeList>}
   */
  waitForElements(selector, minCount = 1, timeout = 10000) {
    return new Promise((resolve, reject) => {
      const els = document.querySelectorAll(selector);
      if (els.length >= minCount) return resolve(els);

      const observer = new MutationObserver(() => {
        const els = document.querySelectorAll(selector);
        if (els.length >= minCount) {
          observer.disconnect();
          resolve(els);
        }
      });

      observer.observe(document.body, { childList: true, subtree: true });

      setTimeout(() => {
        observer.disconnect();
        const els = document.querySelectorAll(selector);
        if (els.length > 0) resolve(els);
        else reject(new Error(`Elements "${selector}" not found within ${timeout}ms`));
      }, timeout);
    });
  },

  /**
   * Scrape project cards from the /jobs/ listing page
   * @returns {Array<Object>} — Array of {title, description, skills, projectUrl, projectId}
   */
  scrapeProjectCards() {
    const projects = [];
    // Project links follow the pattern /projects/{category}/{slug}
    const allLinks = document.querySelectorAll('a[href*="/projects/"]');
    const seenUrls = new Set();

    allLinks.forEach((link) => {
      const href = link.getAttribute('href');
      if (!href || seenUrls.has(href)) return;
      // Only grab title-level links (not "Bid now" links or skill tags)
      const text = link.textContent.trim();
      if (!text || text === 'Bid now' || text === 'Enter now' || text.length < 10) return;

      const fullUrl = href.startsWith('http')
        ? href
        : `https://www.freelancer.pk${href}`;

      // Extract project ID from URL slug
      const slugParts = href.split('/');
      const projectId = slugParts[slugParts.length - 1] || href;

      // Try to find description nearby — look at the parent container
      let description = '';
      let parentEl = link.closest('div, li, article, section');
      if (parentEl) {
        // Get text that isn't from other links
        const clone = parentEl.cloneNode(true);
        clone.querySelectorAll('a').forEach((a) => a.remove());
        description = clone.textContent.trim().substring(0, 500);
      }

      // Extract skill tags nearby
      let skills = [];
      if (parentEl) {
        const skillLinks = parentEl.querySelectorAll('a[href*="/jobs/"]');
        skillLinks.forEach((sl) => {
          const skillText = sl.textContent.trim();
          if (skillText && skillText.length < 50) {
            skills.push(skillText);
          }
        });
      }

      seenUrls.add(href);
      projects.push({
        title: text,
        description,
        skills,
        projectUrl: fullUrl,
        projectId,
      });
    });

    return projects;
  },

  /**
   * Extract full project details from a project detail page
   * @returns {Object} — {title, description, budget, deliveryDays, projectId, skills}
   */
  scrapeProjectDetails() {
    let title = '';
    let description = '';
    let budget = '';
    let deliveryDays = '';
    let skills = [];

    // Title: usually the largest heading on the page
    const h1 = document.querySelector('h1');
    if (h1) title = h1.textContent.trim();

    // Description: look for the project description container
    // Freelancer.pk uses various containers
    const descSelectors = [
      '.project-details',
      '[class*="description"]',
      '.ProjectDescription',
      '.project-detail-description',
      'app-project-details',
    ];

    for (const sel of descSelectors) {
      const el = document.querySelector(sel);
      if (el) {
        description = el.textContent.trim().substring(0, 2000);
        break;
      }
    }

    // If no specific description container, grab from page body text
    if (!description) {
      const paragraphs = document.querySelectorAll('p');
      const texts = [];
      paragraphs.forEach((p) => {
        const t = p.textContent.trim();
        if (t.length > 50) texts.push(t);
      });
      description = texts.join('\n').substring(0, 2000);
    }

    // Budget: look for budget/price elements
    const budgetSelectors = [
      '[class*="Budget"] span',
      '[class*="budget"]',
      '[class*="prize"]',
      '[class*="price"]',
    ];

    for (const sel of budgetSelectors) {
      const el = document.querySelector(sel);
      if (el) {
        budget = el.textContent.trim();
        break;
      }
    }

    // Also try to find budget from text patterns in the page
    if (!budget) {
      const allText = document.body.innerText;
      const budgetMatch = allText.match(/\$[\d,]+(?:\s*-\s*\$[\d,]+)?\s*(?:USD|PKR|EUR|GBP)?/);
      if (budgetMatch) budget = budgetMatch[0];
    }

    // Delivery days
    const daysSelectors = [
      '[class*="delivery"]',
      '[class*="deadline"]',
      '[class*="Duration"]',
    ];

    for (const sel of daysSelectors) {
      const el = document.querySelector(sel);
      if (el) {
        const text = el.textContent.trim();
        const match = text.match(/(\d+)\s*day/i);
        if (match) {
          deliveryDays = match[1];
          break;
        }
      }
    }

    if (!deliveryDays) {
      const allText = document.body.innerText;
      const daysMatch = allText.match(/(\d+)\s*days?\s*(?:left|delivery|deadline)/i);
      if (daysMatch) deliveryDays = daysMatch[1];
    }

    // Skills
    const skillLinks = document.querySelectorAll('a[href*="/jobs/"]');
    skillLinks.forEach((sl) => {
      const t = sl.textContent.trim();
      if (t && t.length < 50 && !skills.includes(t)) {
        skills.push(t);
      }
    });

    // Project ID from URL
    const urlParts = window.location.pathname.split('/');
    const projectId = urlParts[urlParts.length - 1] || window.location.pathname;

    return { title, description, budget, deliveryDays, projectId, skills };
  },

  /**
   * Find and fill the bid form on a project detail page
   * @param {Object} bidData — {amount, days, proposal}
   * @returns {boolean} — true if form was filled
   */
  async fillBidForm(bidData) {
    // Set value and dispatch events to trigger Angular bindings
    function setInputValue(input, value) {
      const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
        window.HTMLInputElement.prototype, 'value'
      ).set;
      nativeInputValueSetter.call(input, value);
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      input.dispatchEvent(new Event('blur', { bubbles: true }));
    }

    function setTextareaValue(textarea, value) {
      const nativeTextareaSetter = Object.getOwnPropertyDescriptor(
        window.HTMLTextAreaElement.prototype, 'value'
      ).set;
      nativeTextareaSetter.call(textarea, value);
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
      textarea.dispatchEvent(new Event('change', { bubbles: true }));
      textarea.dispatchEvent(new Event('blur', { bubbles: true }));
    }

    let filled = { amount: false, days: false, proposal: false };

    // Find bid amount input
    const amountInputs = document.querySelectorAll(
      'input[type="number"], input[type="text"]'
    );
    for (const input of amountInputs) {
      const placeholder = (input.placeholder || '').toLowerCase();
      const name = (input.name || '').toLowerCase();
      const label = input.closest('label')?.textContent?.toLowerCase() || '';
      const nearby = input.parentElement?.textContent?.toLowerCase() || '';

      if (placeholder.includes('amount') || placeholder.includes('bid') ||
          placeholder.includes('budget') || name.includes('amount') ||
          name.includes('bid') || label.includes('bid') ||
          nearby.includes('bid amount') || nearby.includes('your bid')) {
        setInputValue(input, bidData.amount);
        filled.amount = true;
        break;
      }
    }

    // Find delivery days input
    for (const input of amountInputs) {
      const placeholder = (input.placeholder || '').toLowerCase();
      const name = (input.name || '').toLowerCase();
      const nearby = input.parentElement?.textContent?.toLowerCase() || '';

      if (placeholder.includes('day') || placeholder.includes('deliver') ||
          name.includes('day') || name.includes('period') ||
          nearby.includes('deliver') || nearby.includes('days')) {
        setInputValue(input, bidData.days);
        filled.days = true;
        break;
      }
    }

    // Find proposal textarea
    const textareas = document.querySelectorAll('textarea');
    for (const ta of textareas) {
      const placeholder = (ta.placeholder || '').toLowerCase();
      const name = (ta.name || '').toLowerCase();
      const nearby = ta.parentElement?.textContent?.toLowerCase() || '';

      if (placeholder.includes('proposal') || placeholder.includes('describe') ||
          placeholder.includes('message') || name.includes('description') ||
          name.includes('proposal') || nearby.includes('proposal') ||
          nearby.includes('describe your')) {
        setTextareaValue(ta, bidData.proposal);
        filled.proposal = true;
        break;
      }
    }

    // Fallback: if only one textarea found, use it
    if (!filled.proposal && textareas.length === 1) {
      setTextareaValue(textareas[0], bidData.proposal);
      filled.proposal = true;
    }

    return filled;
  },

  /**
   * Click the Place Bid / Submit button
   * @returns {boolean}
   */
  clickSubmitBid() {
    const buttons = document.querySelectorAll('button, input[type="submit"]');
    for (const btn of buttons) {
      const text = btn.textContent.trim().toLowerCase();
      if (text.includes('place bid') || text.includes('submit') ||
          text.includes('send bid') || text.includes('place a bid')) {
        btn.click();
        return true;
      }
    }
    return false;
  }
};

if (typeof globalThis !== 'undefined') {
  globalThis.Scraper = Scraper;
}
