/**
 * storage.js — Chrome Storage Utility
 * Handles settings, processed projects, logs, and stats.
 * API key has been removed — all AI calls go through backend proxy.
 */
var StorageUtil = StorageUtil || {
  DEFAULTS: {
    keywords: '',
    budgetReduction: 10,
    daysReduction: 20,
    maxBids: 15,
    delayBetweenBids: 5,
    autoSubmit: false,
    aiPersona: 'professional freelancer',
  },

  async getSettings() {
    return new Promise((resolve) => {
      chrome.storage.local.get('settings', (result) => {
        resolve({ ...StorageUtil.DEFAULTS, ...result.settings });
      });
    });
  },

  async saveSettings(settings) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ settings }, resolve);
    });
  },

  async getProcessedProjects() {
    return new Promise((resolve) => {
      chrome.storage.local.get('processedProjects', (result) => {
        resolve(result.processedProjects || {});
      });
    });
  },

  async markProjectProcessed(projectId) {
    const processed = await StorageUtil.getProcessedProjects();
    processed[projectId] = Date.now();
    return new Promise((resolve) => {
      chrome.storage.local.set({ processedProjects: processed }, resolve);
    });
  },

  async isProjectProcessed(projectId) {
    const processed = await StorageUtil.getProcessedProjects();
    return !!processed[projectId];
  },

  async clearProcessedProjects() {
    return new Promise((resolve) => {
      chrome.storage.local.set({ processedProjects: {} }, resolve);
    });
  },

  async getStats() {
    return new Promise((resolve) => {
      chrome.storage.local.get('stats', (result) => {
        resolve(result.stats || { bidsPlaced: 0, projectsScanned: 0, successRate: 0 });
      });
    });
  },

  async updateStats(field, value) {
    const stats = await StorageUtil.getStats();
    if (typeof value === 'number') {
      stats[field] = value;
    } else {
      stats[field] = (stats[field] || 0) + 1;
    }
    if (stats.projectsScanned > 0) {
      stats.successRate = Math.round((stats.bidsPlaced / stats.projectsScanned) * 100);
    }
    return new Promise((resolve) => {
      chrome.storage.local.set({ stats }, resolve);
    });
  },

  async resetStats() {
    return new Promise((resolve) => {
      chrome.storage.local.set({ stats: { bidsPlaced: 0, projectsScanned: 0, successRate: 0 } }, resolve);
    });
  },

  async getState() {
    return new Promise((resolve) => {
      chrome.storage.local.get('automationState', (result) => {
        resolve(result.automationState || { running: false, currentPage: 1, bidCount: 0 });
      });
    });
  },

  async saveState(state) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ automationState: state }, resolve);
    });
  }
};

if (typeof globalThis !== 'undefined') {
  globalThis.StorageUtil = StorageUtil;
}
